#!/usr/bin/env python
"""
generate_strike_animation_data.py

Reads:
    dataMap/data/processed/strike_scenario_US_RU_GLOBAL.json

Produces:
    dataMap/data/processed/strike_animation_US_RU_GLOBAL.json

For each strike, it adds:
    - distance_km
    - total_travel_time_minutes (estimated from delivery_system + distance)
    - impact_time_hours  (wave_time_hours + total_travel_time_minutes / 60)
    - average_speed_km_s
    - ballistic_profile (for ICBM/SLBM): "nominal" or "depressed"
    - phase_breakdown_minutes: {boost, midcourse, terminal} for ballistic, or {cruise} for others
    - arc_points: list of per-point dicts:
        {
            "lat": float,
            "lon": float,
            "t_frac": float in [0, 1],
            "phase": "boost" | "midcourse" | "terminal" | "cruise"
        }

Travel times and phases are approximate but tuned to be plausible for
intercontinental shots, especially for ICBM/SLBM.
"""

import os
import json
import math
from datetime import datetime
from typing import List, Dict, Any, Tuple


# -------------------------------
# Paths
# -------------------------------

BASE_DIR = os.path.dirname(__file__)
DATAMAP_DIR = os.path.join(BASE_DIR, "dataMap")
DATA_DIR = os.path.join(DATAMAP_DIR, "data")
PROCESSED_DIR = os.path.join(DATA_DIR, "processed")

SCENARIO_PATH = os.path.join(PROCESSED_DIR, "strike_scenario_US_RU_GLOBAL.json")
OUTPUT_PATH = os.path.join(PROCESSED_DIR, "strike_animation_US_RU_GLOBAL.json")


# -------------------------------
# Geometry helpers
# -------------------------------

def haversine_distance_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Great-circle distance between two points on Earth (km).
    """
    R = 6371.0  # km
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)

    a = math.sin(dphi / 2.0) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2.0) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


def interpolate_great_circle_points(
    lat1: float,
    lon1: float,
    lat2: float,
    lon2: float,
    num_points: int
) -> List[Tuple[float, float]]:
    """
    Generate points along the great-circle path between (lat1, lon1) and (lat2, lon2).

    Returns a list of (lat, lon) in degrees.

    Uses spherical linear interpolation (slerp) between unit vectors to
    stay on a great-circle, rather than interpolating lat/lon directly.
    """
    if num_points < 2:
        num_points = 2

    # Convert degrees to radians
    lat1_rad = math.radians(lat1)
    lon1_rad = math.radians(lon1)
    lat2_rad = math.radians(lat2)
    lon2_rad = math.radians(lon2)

    # Convert to 3D Cartesian coordinates on unit sphere
    def to_cart(lat_r, lon_r):
        return [
            math.cos(lat_r) * math.cos(lon_r),
            math.cos(lat_r) * math.sin(lon_r),
            math.sin(lat_r),
        ]

    p1 = to_cart(lat1_rad, lon1_rad)
    p2 = to_cart(lat2_rad, lon2_rad)

    # Angle between p1 and p2
    dot = max(-1.0, min(1.0, p1[0] * p2[0] + p1[1] * p2[1] + p1[2] * p2[2]))
    omega = math.acos(dot)

    if omega == 0.0:
        # Points are identical; return a degenerate line
        return [(lat1, lon1)] * num_points

    sin_omega = math.sin(omega)
    points: List[Tuple[float, float]] = []

    for i in range(num_points):
        t = i / (num_points - 1)
        sin_t_omega = math.sin(t * omega)
        sin_1_t_omega = math.sin((1.0 - t) * omega)

        k1 = sin_1_t_omega / sin_omega
        k2 = sin_t_omega / sin_omega

        x = k1 * p1[0] + k2 * p2[0]
        y = k1 * p1[1] + k2 * p2[1]
        z = k1 * p1[2] + k2 * p2[2]

        lat_r = math.atan2(z, math.sqrt(x * x + y * y))
        lon_r = math.atan2(y, x)

        points.append((math.degrees(lat_r), math.degrees(lon_r)))

    return points


# -------------------------------
# Travel time & phase models
# -------------------------------

def estimate_ballistic_profile(distance_km: float, system: str) -> Tuple[str, float]:
    """
    Decide whether to use a 'nominal' or 'depressed' ballistic trajectory
    and return (profile_name, total_travel_time_minutes).

    Very rough, but plausible:

      ICBM / SLBM:
        - Short (~1000–3000 km): depressed: ~12–18 min
        - Medium (~3000–7000 km): nominal: ~18–25 min, depressed: maybe ~14–20
        - Long (~7000–11000 km): nominal: ~25–35 min

    We keep it simple and deterministic based on distance.
    """
    system = system.upper()

    # Cap distances to reasonable ICBM/SLBM ranges for this model
    d = max(500.0, min(distance_km, 11000.0))

    # Very rough heuristics
    if d < 3000.0:
        # Mostly regional shots: can be quite fast
        profile = "depressed"
        # 12–18 minutes depending on distance
        t_min = 10.0 + (d - 500.0) / 250.0  # ~10->18 min
        t = max(8.0, min(18.0, t_min))
    elif d < 7000.0:
        # Inter-theater, but not full ICBM max range
        if system == "SLBM":
            # SLBMs often used for faster/depressed trajectories
            profile = "depressed"
            # 14–22 minutes
            t_min = 14.0 + (d - 3000.0) / 400.0  # ~14->22
            t = max(12.0, min(22.0, t_min))
        else:
            profile = "nominal"
            # 18–26 minutes
            t_min = 18.0 + (d - 3000.0) / 500.0  # ~18->26
            t = max(16.0, min(26.0, t_min))
    else:
        # Full intercontinental arcs
        profile = "nominal"
        # 25–35 minutes
        t_min = 25.0 + (d - 7000.0) / 800.0  # ~25->35
        t = max(22.0, min(35.0, t_min))

    return profile, t


def breakdown_ballistic_phases(total_minutes: float, profile: str) -> Dict[str, float]:
    """
    Split total ballistic flight time into boost / midcourse / terminal.
    Very rough fractions; tweaked by profile type.
    """
    profile = profile.lower()

    if profile == "depressed":
        # Shorter midcourse, relatively larger boost/terminal fraction
        boost_frac = 0.18
        term_frac = 0.22
    else:
        # Nominal full ballistic arc
        boost_frac = 0.12
        term_frac = 0.18

    mid_frac = max(0.0, 1.0 - boost_frac - term_frac)

    boost = total_minutes * boost_frac
    mid = total_minutes * mid_frac
    term = total_minutes * term_frac

    # Ensure exact sum by minor adjustment on midcourse
    correction = total_minutes - (boost + mid + term)
    mid += correction

    return {
        "boost": boost,
        "midcourse": mid,
        "terminal": term,
    }


def estimate_bomber_flight_time_minutes(distance_km: float) -> float:
    """
    Approximate bomber flight time:

      - Cruise ~800 km/h
      - Add overhead for takeoff/ingress/egress
      - Clamp to reasonable range
    """
    time_hours = distance_km / 800.0 + 1.5  # overhead
    time_hours = max(1.5, min(18.0, time_hours))  # don't go crazy long
    return time_hours * 60.0


def estimate_unknown_flight_time_minutes(distance_km: float) -> float:
    """
    Fallback for UNKNOWN delivery_system.

    Treat as generic 'fast strike' somewhere between 8–30 minutes.
    """
    base = 10.0 + distance_km / 600.0
    return max(8.0, min(30.0, base))


def estimate_travel_time_and_phases(delivery_system: str, distance_km: float) -> Tuple[float, str, Dict[str, float]]:
    """
    Return (total_minutes, profile, phase_breakdown_minutes).

    For ballistic (ICBM/SLBM), profile is 'nominal' or 'depressed',
    and phase_breakdown has boost/midcourse/terminal.

    For BOMBER/UNKNOWN, profile is 'cruise', and phase_breakdown has only 'cruise'.
    """
    ds = (delivery_system or "UNKNOWN").upper()

    if ds in ("ICBM", "SLBM"):
        profile, total = estimate_ballistic_profile(distance_km, ds)
        phases = breakdown_ballistic_phases(total, profile)
        return total, profile, phases

    if ds == "BOMBER":
        total = estimate_bomber_flight_time_minutes(distance_km)
        phases = {"cruise": total}
        return total, "cruise", phases

    total = estimate_unknown_flight_time_minutes(distance_km)
    phases = {"cruise": total}
    return total, "cruise", phases


# -------------------------------
# Arc construction with phases
# -------------------------------

def build_arc_points_with_phases(
    origin_lat: float,
    origin_lon: float,
    target_lat: float,
    target_lon: float,
    phases_minutes: Dict[str, float],
    profile: str,
    base_num_points: int = 64,
) -> List[Dict[str, Any]]:
    """
    Build arc points for visualization.

    We:
      - Generate a great-circle path with base_num_points points.
      - Assign each point:
          * t_frac in [0,1]
          * phase: 'boost', 'midcourse', 'terminal' (ballistic) or 'cruise' (others)

    Phase assignment is based on the *time fraction* along the trajectory,
    using the cumulative phase durations.
    """
    # Sort phases in a logical order for ballistic, or just single phase for cruise
    if "boost" in phases_minutes:
        # Ballistic ordering
        phase_order = ["boost", "midcourse", "terminal"]
    else:
        # Cruise-only
        phase_order = ["cruise"]

    total_minutes = sum(phases_minutes[p] for p in phase_order)
    if total_minutes <= 0.0:
        total_minutes = 1.0

    # Cumulative phase boundaries in [0,1] (fractions of time)
    cum_bounds = {}
    cum = 0.0
    for p in phase_order:
        frac = phases_minutes[p] / total_minutes
        next_cum = cum + frac
        cum_bounds[p] = (cum, next_cum)
        cum = next_cum
    # Fix rounding errors
    last_p = phase_order[-1]
    start_last, _ = cum_bounds[last_p]
    cum_bounds[last_p] = (start_last, 1.0)

    # Interpolate along great-circle
    pts = interpolate_great_circle_points(
        origin_lat,
        origin_lon,
        target_lat,
        target_lon,
        base_num_points,
    )

    arc_points: List[Dict[str, Any]] = []
    for i, (lat, lon) in enumerate(pts):
        t_frac = i / (len(pts) - 1) if len(pts) > 1 else 0.0

        # Determine phase for this point based on t_frac
        phase_for_point = phase_order[-1]
        for p in phase_order:
            start, end = cum_bounds[p]
            if start <= t_frac <= end:
                phase_for_point = p
                break

        arc_points.append(
            {
                "lat": lat,
                "lon": lon,
                "t_frac": t_frac,
                "phase": phase_for_point,
            }
        )

    return arc_points


# -------------------------------
# Main
# -------------------------------

def main():
    print(f"[Paths] Scenario: {SCENARIO_PATH}")
    print(f"[Paths] Output:   {OUTPUT_PATH}")

    if not os.path.exists(SCENARIO_PATH):
        raise FileNotFoundError(f"Scenario file not found at {SCENARIO_PATH}")

    with open(SCENARIO_PATH, "r", encoding="utf-8") as f:
        strikes = json.load(f)

    print(f"[Load] Loaded {len(strikes):,} strikes from scenario JSON.")

    enriched: List[Dict[str, Any]] = []
    travel_stats_by_system: Dict[str, List[float]] = {}

    for s in strikes:
        from_pt = s.get("from", {})
        to_pt = s.get("to", {})

        try:
            o_lat = float(from_pt["lat"])
            o_lon = float(from_pt["lon"])
            t_lat = float(to_pt["lat"])
            t_lon = float(to_pt["lon"])
        except (KeyError, TypeError, ValueError):
            # Skip malformed entries
            continue

        distance_km = haversine_distance_km(o_lat, o_lon, t_lat, t_lon)
        delivery_system = s.get("delivery_system", "UNKNOWN")

        total_minutes, profile, phases_minutes = estimate_travel_time_and_phases(
            delivery_system, distance_km
        )

        wave_time_hours = float(s.get("wave_time_hours", 0.0))
        impact_time_hours = wave_time_hours + total_minutes / 60.0

        avg_speed_km_s = 0.0
        if total_minutes > 0.0:
            avg_speed_km_s = distance_km / (total_minutes * 60.0)

        arc_points = build_arc_points_with_phases(
            o_lat,
            o_lon,
            t_lat,
            t_lon,
            phases_minutes,
            profile,
            base_num_points=64,
        )

        s_enriched = dict(s)  # shallow copy of original strike
        s_enriched["distance_km"] = distance_km
        s_enriched["total_travel_time_minutes"] = total_minutes
        s_enriched["impact_time_hours"] = impact_time_hours
        s_enriched["average_speed_km_s"] = avg_speed_km_s
        s_enriched["ballistic_profile"] = profile
        s_enriched["phase_breakdown_minutes"] = phases_minutes
        s_enriched["arc_points"] = arc_points

        enriched.append(s_enriched)

        ds_key = (delivery_system or "UNKNOWN").upper()
        travel_stats_by_system.setdefault(ds_key, []).append(total_minutes)

    # Simple stats dump
    print("[Stats] Total travel time (minutes) by delivery_system (min / max / mean):")
    for ds_key, times in travel_stats_by_system.items():
        if not times:
            continue
        t_min = min(times)
        t_max = max(times)
        t_mean = sum(times) / len(times)
        print(f"   {ds_key:8s}: min={t_min:5.1f}, max={t_max:5.1f}, mean={t_mean:5.1f}")

    meta = {
        "source_file": os.path.basename(SCENARIO_PATH),
        "generated_at_utc": datetime.utcnow().isoformat() + "Z",
        "num_strikes": len(enriched),
        "notes": (
            "Travel times and phases are approximate and intended for visualization. "
            "Ballistic arcs are great-circle paths from launch origin to target."
        ),
    }

    out = {
        "meta": meta,
        "strikes": enriched,
    }

    os.makedirs(PROCESSED_DIR, exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)

    print(f"[Output] Wrote enriched animation data to {OUTPUT_PATH}")


if __name__ == "__main__":
    main()

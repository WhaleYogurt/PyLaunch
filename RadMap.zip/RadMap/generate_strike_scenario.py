#!/usr/bin/env python
import os
import json
import math
import random
from datetime import datetime
from typing import Dict, Any, List, Tuple

import pandas as pd


# -------------------------------
# Paths
# -------------------------------

BASE_DIR = os.path.dirname(__file__)
DATAMAP_DIR = os.path.join(BASE_DIR, "dataMap")
DATA_DIR = os.path.join(DATAMAP_DIR, "data")
PROCESSED_DIR = os.path.join(DATA_DIR, "processed")

MASTER_PATH = os.path.join(PROCESSED_DIR, "data.csv")
NUCLEAR_FORCES_PATH = os.path.join(BASE_DIR, "nuclear_forces.json")
ALLEGIANCES_PATH = os.path.join(DATA_DIR, "master_allegiances.csv")

OUTPUT_PATH = os.path.join(PROCESSED_DIR, "strike_scenario_US_RU_GLOBAL.json")


# -------------------------------
# Helpers
# -------------------------------

def haversine_distance_km(lat1, lon1, lat2, lon2) -> float:
    """
    Great-circle distance between two points on Earth (km).
    """
    R = 6371.0  # km
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)

    a = math.sin(dphi / 2.0) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2.0) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


def log1p_safe(x):
    try:
        return math.log1p(float(x))
    except (ValueError, TypeError):
        return 0.0


def normalize_series(s: pd.Series) -> pd.Series:
    s = s.astype(float)
    min_val = s.min()
    max_val = s.max()
    if max_val == min_val:
        return pd.Series([0.0] * len(s), index=s.index)
    return (s - min_val) / (max_val - min_val)


# -------------------------------
# Scenario & model definitions
# -------------------------------

# Simple "mainland" origins kept for compatibility / fallback
LAUNCH_ORIGINS_SIMPLE = {
    "UnitedStates": {"lat": 39.0, "lon": -98.0, "label": "US mainland"},
    "Russia": {"lat": 60.0, "lon": 90.0, "label": "Russian mainland"},
    "China": {"lat": 35.0, "lon": 103.0, "label": "Chinese mainland"},
}

# Extended origins by delivery system (very approximate, for nicer arcs)
LAUNCH_ORIGINS_EXTENDED: Dict[str, Dict[str, List[Dict[str, Any]]]] = {
    "UnitedStates": {
        "ICBM": [
            {"lat": 46.5, "lon": -101.0, "label": "US ICBM fields (Northern Plains)"},
        ],
        "SLBM": [
            {"lat": 45.0, "lon": -30.0, "label": "US SLBM North Atlantic patrol"},
            {"lat": 35.0, "lon": -140.0, "label": "US SLBM North Pacific patrol"},
        ],
        "BOMBER": [
            {"lat": 48.0, "lon": -100.0, "label": "US bomber bases (approx)"},
        ],
        "DEFAULT": [
            {"lat": 39.0, "lon": -98.0, "label": "US mainland"},
        ],
    },
    "Russia": {
        "ICBM": [
            {"lat": 55.0, "lon": 60.0, "label": "Russian ICBM fields (Urals)"},
        ],
        "SLBM": [
            {"lat": 65.0, "lon": 40.0, "label": "Russian SLBM Barents Sea patrol"},
            {"lat": 50.0, "lon": 150.0, "label": "Russian SLBM Pacific patrol"},
        ],
        "BOMBER": [
            {"lat": 55.0, "lon": 40.0, "label": "Russian bomber bases (approx)"},
        ],
        "DEFAULT": [
            {"lat": 60.0, "lon": 90.0, "label": "Russian mainland"},
        ],
    },
    "China": {
        "ICBM": [
            {"lat": 38.0, "lon": 105.0, "label": "Chinese ICBM fields (interior)"},
        ],
        "SLBM": [
            {"lat": 20.0, "lon": 120.0, "label": "Chinese SLBM South China Sea patrol"},
        ],
        "BOMBER": [
            {"lat": 35.0, "lon": 115.0, "label": "Chinese bomber bases (approx)"},
        ],
        "DEFAULT": [
            {"lat": 35.0, "lon": 103.0, "label": "Chinese mainland"},
        ],
    },
}

ATTACKER_TO_SCORE_COL = {
    "UnitedStates": "score_us",
    "Russia": "score_ru",
    "China": "score_cn",
}

# Map attacker key -> priority column written by apply_military_priority_v2.py
ATTACKER_TO_PRIORITY_COL = {
    "UnitedStates": "priority_US",
    "Russia": "priority_RU",
    "China": "priority_CN",
}

NUCLEAR_ISO = {"US", "RU", "CN", "FR", "GB", "UK", "IN", "PK", "IL", "KP"}

# Fallback fictional type-based priorities (if priority_US/priority_RU/priority_CN missing)
TYPE_PRIORITY: Dict[str, Dict[str, Dict[str, int]]] = {
    "UnitedStates": {
        "SSBN_BASE": 5,
        "ICBM_COMPLEX": 5,
        "MISSILE_FIELD": 5,
        "AIRBASE_STRATEGIC": 4,
        "NAVAL_BASE_MAJOR": 4,
        "ARMY_HEADQUARTERS": 4,
        "COMMAND_AND_CONTROL": 5,
        "RADAR": 3,
        "EARLY_WARNING": 3,
        "AIRBASE_TACTICAL": 3,
        "NAVAL_BASE_MINOR": 2,
        "LOGISTICS_DEPOT": 2,
        "TRAINING_BASE": 1,
        "OTHER": 1,
    },
    "Russia": {
        "SSBN_BASE": 5,
        "ICBM_COMPLEX": 5,
        "MISSILE_FIELD": 5,
        "AIRBASE_STRATEGIC": 4,
        "NAVAL_BASE_MAJOR": 4,
        "ARMY_HEADQUARTERS": 4,
        "COMMAND_AND_CONTROL": 5,
        "RADAR": 3,
        "EARLY_WARNING": 3,
        "AIRBASE_TACTICAL": 3,
        "NAVAL_BASE_MINOR": 2,
        "LOGISTICS_DEPOT": 2,
        "TRAINING_BASE": 1,
        "OTHER": 1,
    },
    "China": {
        "SSBN_BASE": 5,
        "ICBM_COMPLEX": 5,
        "MISSILE_FIELD": 5,
        "AIRBASE_STRATEGIC": 4,
        "NAVAL_BASE_MAJOR": 4,
        "ARMY_HEADQUARTERS": 4,
        "COMMAND_AND_CONTROL": 5,
        "RADAR": 3,
        "EARLY_WARNING": 3,
        "AIRBASE_TACTICAL": 3,
        "NAVAL_BASE_MINOR": 2,
        "LOGISTICS_DEPOT": 2,
        "TRAINING_BASE": 1,
        "OTHER": 1,
    },
}
DEFAULT_TYPE_PRIORITY = 1  # fallback if nothing else exists


SCENARIO_KEY = "US_RU_GLOBAL"

SCENARIO_CONFIG = {
    "US_RU_GLOBAL": {
        "description": "All-out US–Russia global nuclear exchange (abstract simulation).",
        "attackers": ["UnitedStates", "Russia"],
        "targets": {
            "UnitedStates": ["Russia"],
            "Russia": [
                "United States",
                "United States of America",
                "USA",
                "Canada",
                "United Kingdom",
                "France",
                "Germany",
                "Poland",
                "Italy",
                "Spain",
                "Netherlands",
                "Belgium",
                "Norway",
                "Denmark",
                "Portugal",
                "Czech Republic",
                "Romania",
                "Sweden",
                "Finland",
                "Lithuania",
                "Latvia",
                "Estonia",
            ],
        },
        # simple timeline in hours after scenario start
        "wave_timing_hours": {
            "wave1": 0.0,
            "wave2": 6.0,
            "wave3": 24.0,
        },
    }
}

# Default per-delivery-system failure rates (probability the warhead fails to reach / detonate)
DEFAULT_FAILURE_RATES = {
    "ICBM": 0.20,
    "SLBM": 0.15,
    "BOMBER": 0.30,
    "UNKNOWN": 0.25,
}

# Yield parameters (very rough; mean/std in kilotons)
YIELD_CLASS_PARAMS = {
    "very_high": {"mean_kt": 500.0, "std_kt": 150.0},
    "high": {"mean_kt": 300.0, "std_kt": 100.0},
    "medium": {"mean_kt": 150.0, "std_kt": 50.0},
    "low": {"mean_kt": 50.0, "std_kt": 20.0},
}


# -------------------------------
# City / military importance
# -------------------------------

def compute_city_importance(df: pd.DataFrame) -> pd.Series:
    pop = df.get("population")
    if pop is not None:
        pop = pop.fillna(0)
        pop_score = normalize_series(pop.clip(lower=1).apply(math.log))
    else:
        pop_score = pd.Series([0.0] * len(df), index=df.index)

    ind_count = df.get("osm_industrial_count", pd.Series(0, index=df.index)).fillna(0)
    ind_raw = ind_count.apply(log1p_safe)
    ind_score = normalize_series(ind_raw) if ind_raw.max() > 0 else pd.Series([0.0] * len(df), index=df.index)

    mil_count = df.get("osm_military_count", pd.Series(0, index=df.index)).fillna(0)
    mil_raw = mil_count.apply(log1p_safe)
    mil_score = normalize_series(mil_raw) if mil_raw.max() > 0 else pd.Series([0.0] * len(df), index=df.index)

    if "is_capital" in df.columns:
        cap_score = df["is_capital"].fillna(0).astype(int)
    else:
        cap_score = pd.Series([0.0] * len(df), index=df.index)

    base_score = 0.45 * pop_score + 0.25 * ind_score + 0.20 * mil_score + 0.10 * cap_score
    return normalize_series(base_score)


def classify_silo_row(row: pd.Series) -> bool:
    text_bits = []
    for col in ["name", "Name", "type", "role", "notes", "description"]:
        if col in row and isinstance(row[col], str):
            text_bits.append(row[col])
    text = " ".join(text_bits).lower()

    keywords = [
        "silo",
        "icbm",
        "missile field",
        "launch facility",
        "launch control",
        "minuteman",
        "ssbn base",
        "ssbn",
        "ballistic missile",
    ]
    return any(k in text for k in keywords)


def compute_military_importance(df: pd.DataFrame) -> pd.Series:
    if "importance" in df.columns:
        imp_raw = df["importance"].fillna(0).astype(float)
        imp_score = normalize_series(imp_raw)
    else:
        imp_score = pd.Series([0.0] * len(df), index=df.index)

    mil_count = df.get("osm_military_count", pd.Series(0, index=df.index)).fillna(0)
    mil_raw = mil_count.apply(log1p_safe)
    mil_osm_score = normalize_series(mil_raw) if mil_raw.max() > 0 else pd.Series([0.0] * len(df), index=df.index)

    if "is_silo" in df.columns:
        silo_flag = df["is_silo"].astype(int)
    else:
        silo_flag = pd.Series([0] * len(df), index=df.index)

    silo_score = silo_flag
    base_score = 0.55 * imp_score + 0.25 * mil_osm_score + 0.20 * silo_score
    return normalize_series(base_score)


def filter_city_like_targets(df: pd.DataFrame) -> pd.DataFrame:
    if "source_layer" in df.columns:
        mask = df["source_layer"].fillna("") == "cities"
        filtered = df[mask].copy()
        if len(filtered) > 0:
            return filtered

    if "population" in df.columns:
        mask = df["population"].notna()
        filtered = df[mask].copy()
        if len(filtered) > 0:
            return filtered

    return df.copy()


def extract_target_pools(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    city_df = filter_city_like_targets(df)

    if "source_layer" in df.columns:
        mil_mask = df["source_layer"].fillna("") == "military_master"
        military_df = df[mil_mask].copy()
    else:
        mil_mask = df.apply(
            lambda r: ("bloc" in df.columns and not pd.isna(r.get("bloc")))
            and ("type" in df.columns and not pd.isna(r.get("type")))
            and ("importance" in df.columns and not pd.isna(r.get("importance"))),
            axis=1,
        )
        military_df = df[mil_mask].copy()

    if not military_df.empty:
        military_df["is_silo"] = military_df.apply(classify_silo_row, axis=1)

    return city_df, military_df


# -------------------------------
# Alignment & nuclear weighting
# -------------------------------

def build_allegiances_index(allegiances_df: pd.DataFrame) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    by_country = {}
    by_iso = {}

    for _, row in allegiances_df.iterrows():
        country = str(row.get("country", "")).strip()
        iso = str(row.get("iso", "")).strip()
        if country:
            by_country[country.lower()] = row
        if iso:
            by_iso[iso.upper()] = row

    return by_country, by_iso


def get_alignment_and_nuclear_factor(
    attacker_key: str,
    country_name: str,
    alleg_country_index: Dict[str, Any],
    alleg_iso_index: Dict[str, Any],
) -> Tuple[float, float]:
    if not isinstance(country_name, str) or not country_name.strip():
        return 0.5, 0.5

    country_key = country_name.strip().lower()
    row = alleg_country_index.get(country_key)

    nuclear_factor = 0.4

    if row is None:
        alignment_factor = 0.5
        return alignment_factor, nuclear_factor

    score_col = ATTACKER_TO_SCORE_COL.get(attacker_key)
    if score_col is None or score_col not in row:
        alignment_factor = 0.5
    else:
        score = float(row[score_col])
        alignment_factor = (-score + 5.0) / 10.0
        alignment_factor = max(0.0, min(1.0, alignment_factor))

    iso = str(row.get("iso", "")).strip().upper()
    if iso in NUCLEAR_ISO:
        nuclear_factor = 1.0
    else:
        if alignment_factor > 0.8:
            nuclear_factor = 0.7
        elif alignment_factor > 0.6:
            nuclear_factor = 0.5
        else:
            nuclear_factor = 0.3

    return alignment_factor, nuclear_factor


# -------------------------------
# Delivery system, yields, MIRV, timing
# -------------------------------

def choose_launch_origin(attacker_key: str, delivery_system: str) -> Dict[str, Any]:
    """
    Choose an approximate launch origin for visual arcs.
    Falls back to simple mainland origin if extended data is missing.
    """
    delivery_system = (delivery_system or "UNKNOWN").upper()
    ext = LAUNCH_ORIGINS_EXTENDED.get(attacker_key)

    if ext:
        candidates = ext.get(delivery_system, []) or ext.get("DEFAULT", []) or []
        if candidates:
            return random.choice(candidates)

    return LAUNCH_ORIGINS_SIMPLE.get(
        attacker_key, {"lat": 0.0, "lon": 0.0, "label": f"{attacker_key} origin"}
    )


def assign_delivery_system(attacker_key: str, target_type: str, wave_name: str, row: pd.Series, priority_val: float) -> str:
    """
    Heuristic delivery system assignment. This is intentionally simple and
    only for visual / modeling flavor.
    """
    is_silo = bool(row.get("is_silo", False))
    wave_name = wave_name.lower()
    target_type = target_type.lower()

    if target_type == "military" and is_silo:
        return "ICBM"

    if target_type == "military" and wave_name == "wave1":
        return "ICBM"

    if target_type == "military" and wave_name == "wave2":
        return "ICBM" if random.random() < 0.7 else "SLBM"

    if target_type == "city":
        if wave_name == "wave1":
            return "SLBM"
        if wave_name == "wave2":
            return "SLBM" if random.random() < 0.5 else "ICBM"
        if wave_name == "wave3":
            return "BOMBER"

    return "UNKNOWN"


def get_failure_rates_for_attacker(forces_cfg: Dict[str, Any]) -> Dict[str, float]:
    """
    Allow nuclear_forces.json to override default failure rates via:
        "failure_rates": {"ICBM": 0.2, "SLBM": 0.15, "BOMBER": 0.3}
    """
    custom = forces_cfg.get("failure_rates") or {}
    rates = DEFAULT_FAILURE_RATES.copy()
    for k, v in custom.items():
        try:
            rates[k.upper()] = float(v)
        except (TypeError, ValueError):
            pass
    return rates


def assign_yield_class(target_type: str, priority_val: float, is_silo: bool, base_score: float) -> str:
    """
    Map target characteristics to a yield class label.
    """
    target_type = target_type.lower()
    priority_val = float(priority_val or 0.0)

    if target_type == "military":
        if is_silo or priority_val >= 5:
            return "very_high"
        if priority_val >= 4:
            return "high"
        if priority_val >= 3:
            return "medium"
        return "low"

    if base_score >= 0.8:
        return "very_high"
    if base_score >= 0.6:
        return "high"
    if base_score >= 0.4:
        return "medium"
    return "low"


def get_yield_params(yield_class: str) -> Tuple[float, float]:
    yc = (yield_class or "medium").lower()
    params = YIELD_CLASS_PARAMS.get(yc, YIELD_CLASS_PARAMS["medium"])
    return params["mean_kt"], params["std_kt"]


def approx_blast_radius_5psi_km(yield_kt: float) -> float:
    """
    Very rough estimate of 5 psi overpressure radius (km), for surface/low air burst.
    R[km] ~ 0.47 * (yield_kt)^(1/3)
    """
    if yield_kt <= 0:
        return 0.0
    return 0.47 * (yield_kt ** (1.0 / 3.0))


def assign_mirv_warheads(delivery_system: str, target_type: str, priority_val: float, base_score: float, is_silo: bool) -> int:
    """
    Simple MIRV model: number of warheads per delivery vehicle.
    Not strictly conserving total warhead count across the scenario.
    """
    delivery_system = (delivery_system or "UNKNOWN").upper()
    target_type = target_type.lower()
    priority_val = float(priority_val or 0.0)

    if delivery_system == "ICBM":
        if is_silo:
            return 1
        if target_type == "city":
            return 2 if base_score < 0.7 else 3
        return 1 if priority_val < 4 else 2

    if delivery_system == "SLBM":
        if target_type == "city":
            return 3 if base_score >= 0.6 else 2
        return 2

    if delivery_system == "BOMBER":
        if target_type == "city":
            return 2
        return 1

    return 1


# -------------------------------
# Scenario generation
# -------------------------------

def filter_targets_by_country_and_range(
    df: pd.DataFrame,
    attacker_key: str,
    scenario_cfg: Dict[str, Any],
    origin: Dict[str, Any],
    max_ic_km: float,
) -> pd.DataFrame:
    target_countries = scenario_cfg["targets"].get(attacker_key, [])
    target_countries_lower = [t.lower() for t in target_countries]

    def is_in_target_country(row) -> bool:
        ctry = row.get("country", None)
        if ctry is None or (isinstance(ctry, float) and math.isnan(ctry)):
            ctry = row.get("Country", None)
        if not isinstance(ctry, str):
            return False
        ctry_lower = ctry.lower()
        if ctry_lower in target_countries_lower:
            return True
        for tgt in target_countries_lower:
            if ctry_lower == tgt:
                return True
            if ctry_lower.startswith(tgt) or tgt.startswith(ctry_lower):
                return True
        return False

    df = df[df.apply(is_in_target_country, axis=1)].copy()
    if df.empty:
        return df

    def within_range(row) -> bool:
        lat = row.get("lat", None)
        lon = row.get("lon", None)
        if lat is None or lon is None:
            return False
        try:
            dist = haversine_distance_km(origin["lat"], origin["lon"], float(lat), float(lon))
        except Exception:
            return False
        return dist <= max_ic_km if max_ic_km > 0 else True

    df = df[df.apply(within_range, axis=1)]
    return df


def get_type_priority_factor(attacker_key: str, row: pd.Series) -> float:
    t = str(row.get("type", "") or "").strip().upper()
    type_table = TYPE_PRIORITY.get(attacker_key, {})
    prio = type_table.get(t, DEFAULT_TYPE_PRIORITY)
    return prio / 5.0


def get_row_priority_from_columns(attacker_key: str, row: pd.Series) -> float:
    col = ATTACKER_TO_PRIORITY_COL.get(attacker_key)
    if col and col in row:
        try:
            val = float(row[col])
        except (TypeError, ValueError):
            val = 0.0
        if val > 0:
            return val / 5.0
    return get_type_priority_factor(attacker_key, row)


def generate_strikes_for_attacker(
    attacker_key: str,
    forces_cfg: Dict[str, Any],
    scenario_cfg: Dict[str, Any],
    city_df: pd.DataFrame,
    military_df: pd.DataFrame,
    alleg_country_index: Dict[str, Any],
    alleg_iso_index: Dict[str, Any],
) -> List[Dict[str, Any]]:
    random.seed(attacker_key)

    origin_simple = LAUNCH_ORIGINS_SIMPLE.get(attacker_key, {"lat": 0.0, "lon": 0.0, "label": f"{attacker_key} origin"})
    max_ic_km = forces_cfg.get("max_intercontinental_range_km", 0) or 0

    city_candidates = filter_targets_by_country_and_range(city_df, attacker_key, scenario_cfg, origin_simple, max_ic_km)
    mil_candidates = filter_targets_by_country_and_range(military_df, attacker_key, scenario_cfg, origin_simple, max_ic_km)

    if city_candidates.empty and mil_candidates.empty:
        print(f"[Scenario] No targetable cities or military sites for attacker {attacker_key}.")
        return []

    if not city_candidates.empty:
        city_candidates["base_score"] = compute_city_importance(city_candidates)
    if not mil_candidates.empty:
        mil_candidates["base_score"] = compute_military_importance(mil_candidates)

    def apply_alignment_and_nuclear(df: pd.DataFrame, is_military: bool) -> pd.DataFrame:
        if df.empty:
            df["alignment_factor"] = []
        alignment_factors = []
        nuclear_factors = []
        attacker_scores = []

        for _, row in df.iterrows():
            ctry = row.get("country") or row.get("Country") or ""
            alignment_factor, nuclear_factor = get_alignment_and_nuclear_factor(
                attacker_key, ctry, alleg_country_index, alleg_iso_index
            )
            alignment_factors.append(alignment_factor)
            nuclear_factors.append(nuclear_factor)

            base_score = float(row.get("base_score", 0.0))
            country_factor = alignment_factor * nuclear_factor

            if is_military:
                silo_flag = bool(row.get("is_silo", False))
                silo_multiplier = 1.3 if silo_flag else 1.0
                prio_factor = get_row_priority_from_columns(attacker_key, row)
                attacker_score = base_score * country_factor * silo_multiplier * prio_factor
            else:
                attacker_score = base_score * country_factor

            attacker_scores.append(attacker_score)

        df["alignment_factor"] = alignment_factors
        df["nuclear_factor"] = nuclear_factors
        df["attacker_score"] = attacker_scores
        return df

    city_candidates = apply_alignment_and_nuclear(city_candidates, is_military=False)
    mil_candidates = apply_alignment_and_nuclear(mil_candidates, is_military=True)

    if not city_candidates.empty:
        city_candidates = city_candidates[city_candidates["alignment_factor"] > 0.15]
    if not mil_candidates.empty:
        mil_candidates = mil_candidates[mil_candidates["alignment_factor"] > 0.15]

    if city_candidates.empty and mil_candidates.empty:
        print(f"[Scenario] After excluding allies, no targets left for attacker {attacker_key}.")
        return []

    city_candidates = city_candidates.sort_values("attacker_score", ascending=False)
    mil_candidates = mil_candidates.sort_values("attacker_score", ascending=False)

    total_units = int(forces_cfg.get("strike_units", 0))
    phase_shares = forces_cfg.get(
        "phase_shares",
        {"wave1": 0.5, "wave2": 0.3, "wave3": 0.2, "reserve": 0.0},
    )
    waves = [w for w in ["wave1", "wave2", "wave3"] if phase_shares.get(w, 0) > 0]

    COUNTERFORCE_FRACTION = {
        "wave1": 0.6,
        "wave2": 0.4,
        "wave3": 0.1,
    }

    # Fractions of the *military* budget per wave that go to "high" / "med"
    MIL_PRIORITY_SHARE = {
        "wave1": {"high": 0.7, "med": 0.2},
        "wave2": {"high": 0.5, "med": 0.3},
        "wave3": {"high": 0.3, "med": 0.3},
    }

    wave_timing = scenario_cfg.get("wave_timing_hours", {})
    failure_rates = get_failure_rates_for_attacker(forces_cfg)

    strikes: List[Dict[str, Any]] = []

    used_military_indices: set = set()

    # --- attacker-specific priority distribution & adaptive buckets ---
    if not mil_candidates.empty:
        prio_col = ATTACKER_TO_PRIORITY_COL.get(attacker_key)
        if prio_col and prio_col in mil_candidates.columns:
            mil_candidates["priority_value"] = pd.to_numeric(
                mil_candidates[prio_col], errors="coerce"
            ).fillna(0)
        else:
            mil_candidates["priority_value"] = mil_candidates.apply(
                lambda r: get_type_priority_factor(attacker_key, r) * 5.0,
                axis=1,
            )

        # Global view for this attacker
        pv = mil_candidates["priority_value"]
        num_total = len(mil_candidates)
        num_p5 = (pv >= 5.0).sum()
        num_p4 = ((pv >= 4.0) & (pv < 5.0)).sum()

        # Adaptive rule:
        # - If plenty of 5s (>=10% of candidates and at least 10), treat 5 as "high" and 4 as "med".
        # - Otherwise, treat 4+5 as "high" and 2 as "med" (for attackers with mostly 2/4 mixes).
        if num_p5 >= max(10, 0.1 * num_total):
            # Classic: high = 5, med = 4
            high_mask = pv >= 5.0
            med_mask = (pv >= 4.0) & (pv < 5.0)
        else:
            # Adaptive: high = 4+5, med = 2 (or mid-range values)
            high_mask = pv >= 4.0
            med_mask = (pv >= 2.0) & (pv < 4.0)

        mil_high = mil_candidates[high_mask]
        mil_med = mil_candidates[med_mask]
        mil_low = mil_candidates[~(high_mask | med_mask)]
    else:
        mil_candidates["priority_value"] = []
        mil_high = mil_med = mil_low = mil_candidates

    def pick_from(df_subset: pd.DataFrame, n: int):
        chosen = []
        if n <= 0:
            return chosen
        for idx, row in df_subset.iterrows():
            if idx in used_military_indices:
                continue
            chosen.append((idx, row))
            used_military_indices.add(idx)
            if len(chosen) >= n:
                break
        return chosen

    def build_strike(row, target_type: str, wave_name: str) -> Dict[str, Any]:
        city_name = row.get("city") or row.get("name") or row.get("City") or "Unknown"
        country = row.get("country") or row.get("Country") or "Unknown"
        lat = float(row.get("lat"))
        lon = float(row.get("lon"))

        base_importance = float(row.get("base_score", 0.0))
        alignment_factor = float(row.get("alignment_factor", 0.0))
        nuclear_factor = float(row.get("nuclear_factor", 0.0))
        attacker_score = float(row.get("attacker_score", 0.0))

        is_silo = bool(row.get("is_silo", False)) if target_type == "military" else False

        priority_val = None
        if target_type == "military":
            if "priority_value" in row:
                try:
                    priority_val = float(row["priority_value"])
                except (TypeError, ValueError):
                    priority_val = None
            else:
                prio_col = ATTACKER_TO_PRIORITY_COL.get(attacker_key)
                if prio_col and prio_col in row:
                    try:
                        priority_val = float(row[prio_col])
                    except (TypeError, ValueError):
                        priority_val = None

        delivery_system = assign_delivery_system(attacker_key, target_type, wave_name, row, priority_val or 0.0)
        origin = choose_launch_origin(attacker_key, delivery_system)
        failure_rate = failure_rates.get(delivery_system, DEFAULT_FAILURE_RATES["UNKNOWN"])
        success_prob = max(0.0, min(1.0, 1.0 - failure_rate))

        yield_class = assign_yield_class(target_type, priority_val or 0.0, is_silo, base_importance)
        yield_mean_kt, yield_std_kt = get_yield_params(yield_class)
        approx_radius_km = approx_blast_radius_5psi_km(yield_mean_kt)

        warheads_per_strike = assign_mirv_warheads(
            delivery_system,
            target_type,
            priority_val or 0.0,
            base_importance,
            is_silo,
        )
        expected_effective_yield_kt = yield_mean_kt * success_prob * warheads_per_strike

        t_plus_hours = float(wave_timing.get(wave_name, 0.0))

        return {
            "scenario": SCENARIO_KEY,
            "attacker": attacker_key,
            "wave": wave_name,
            "wave_time_hours": t_plus_hours,
            "target_type": target_type,
            "is_silo": is_silo,
            "delivery_system": delivery_system,
            "warheads_per_strike": warheads_per_strike,
            "success_probability": success_prob,
            "yield_class": yield_class,
            "yield_mean_kt": yield_mean_kt,
            "yield_std_kt": yield_std_kt,
            "expected_effective_yield_kt": expected_effective_yield_kt,
            "approx_blast_radius_5psi_km": approx_radius_km,
            "from": {
                "lat": origin["lat"],
                "lon": origin["lon"],
                "label": origin["label"],
            },
            "to": {
                "lat": lat,
                "lon": lon,
                "city": city_name,
                "country": country,
            },
            "base_importance": base_importance,
            "alignment_factor": alignment_factor,
            "nuclear_factor": nuclear_factor,
            "attacker_score": attacker_score,
            "priority_value": priority_val,
            "source_layer": row.get("source_layer"),
            "raw_type": row.get("type"),
            "raw_role": row.get("role"),
        }

    for wave_name in waves:
        share = phase_shares.get(wave_name, 0)
        wave_units = int(total_units * share)
        if wave_units <= 0:
            continue

        cf_frac = COUNTERFORCE_FRACTION.get(wave_name, 0.0)
        mil_budget = int(wave_units * cf_frac)
        city_budget = wave_units - mil_budget

        used_mil = 0
        used_city = 0

        pri_shares = MIL_PRIORITY_SHARE.get(wave_name, {"high": 0.5, "med": 0.3})
        high_target = int(mil_budget * pri_shares["high"])
        med_target = int(mil_budget * pri_shares["med"])

        remaining_high = len(set(mil_high.index) - used_military_indices)
        remaining_med = len(set(mil_med.index) - used_military_indices)

        high_quota = min(high_target, remaining_high)
        med_quota = min(med_target, remaining_med)
        remaining_quota = max(0, mil_budget - high_quota - med_quota)

        for _, row in pick_from(mil_high, high_quota):
            strikes.append(build_strike(row, "military", wave_name))
            used_mil += 1

        for _, row in pick_from(mil_med, med_quota):
            if used_mil >= mil_budget:
                break
            strikes.append(build_strike(row, "military", wave_name))
            used_mil += 1

        for _, row in pick_from(mil_low, remaining_quota):
            if used_mil >= mil_budget:
                break
            strikes.append(build_strike(row, "military", wave_name))
            used_mil += 1

        if not city_candidates.empty and city_budget > 0:
            used_indices_city = set()
            for idx, row in city_candidates.iterrows():
                if idx in used_indices_city:
                    continue
                strikes.append(build_strike(row, "city", wave_name))
                used_city += 1
                used_indices_city.add(idx)
                if used_city >= city_budget:
                    break

        print(
            f"[Scenario] Attacker {attacker_key}, {wave_name}: "
            f"{used_mil} military (of {mil_budget}), {used_city} cities (of {city_budget}), "
            f"wave budget {wave_units}."
        )

    if strikes:
        df_strikes = pd.DataFrame(strikes)
        print(f"[Scenario] Summary for attacker {attacker_key}:")
        print(df_strikes.groupby(["wave", "target_type"]).size().to_string())
        if "priority_value" in df_strikes.columns:
            print("[Scenario] Military priority distribution (selected targets):")
            print(
                df_strikes[df_strikes["target_type"] == "military"]["priority_value"]
                .fillna(0)
                .value_counts()
                .sort_index()
                .to_string()
            )

    return strikes


def main():
    print(f"[Paths] Master: {MASTER_PATH}")
    print(f"[Paths] Forces: {NUCLEAR_FORCES_PATH}")
    print(f"[Paths] Allegiances: {ALLEGIANCES_PATH}")
    print(f"[Paths] Output: {OUTPUT_PATH}")

    if not os.path.exists(MASTER_PATH):
        raise FileNotFoundError(f"Master data file not found at {MASTER_PATH}")
    if not os.path.exists(NUCLEAR_FORCES_PATH):
        raise FileNotFoundError(f"nuclear_forces.json not found at {NUCLEAR_FORCES_PATH}")
    if not os.path.exists(ALLEGIANCES_PATH):
        raise FileNotFoundError(f"master_allegiances.csv not found at {ALLEGIANCES_PATH}")

    df = pd.read_csv(MASTER_PATH, low_memory=False)
    print(f"[Master] Loaded {len(df):,} rows from data.csv")

    city_df, military_df = extract_target_pools(df)
    print(f"[Master] City-like rows for targeting: {len(city_df):,}")
    print(f"[Master] Military rows for targeting: {len(military_df):,}")
    if not military_df.empty and "is_silo" in military_df.columns:
        print(f"[Master]   of which silo-like: {int(military_df['is_silo'].sum())}")

    alleg_df = pd.read_csv(ALLEGIANCES_PATH)
    print(f"[Allegiances] Loaded {len(alleg_df):,} rows from master_allegiances.csv")
    alleg_country_index, alleg_iso_index = build_allegiances_index(alleg_df)

    with open(NUCLEAR_FORCES_PATH, "r", encoding="utf-8") as f:
        forces_data = json.load(f)

    scenario_cfg = SCENARIO_CONFIG[SCENARIO_KEY]

    all_strikes: List[Dict[str, Any]] = []
    generated_at = datetime.utcnow().isoformat() + "Z"

    for attacker_key in scenario_cfg["attackers"]:
        if attacker_key not in forces_data:
            print(f"[Warning] No forces config for attacker {attacker_key}, skipping.")
            continue

        forces_cfg = forces_data[attacker_key]
        strikes = generate_strikes_for_attacker(
            attacker_key,
            forces_cfg,
            scenario_cfg,
            city_df,
            military_df,
            alleg_country_index,
            alleg_iso_index,
        )
        all_strikes.extend(strikes)

    print(f"[Scenario] Total strikes generated: {len(all_strikes):,}")

    for s in all_strikes:
        s.setdefault("scenario_description", scenario_cfg.get("description"))
        s.setdefault("generated_at_utc", generated_at)

    os.makedirs(PROCESSED_DIR, exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(all_strikes, f, indent=2)

    print(f"[Output] Wrote strike scenario to {OUTPUT_PATH}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python
"""
apply_military_priority_v2.py

Assigns per-attacker military priority scores (0–5) to military_master rows in:
    dataMap/data/processed/data.csv

Columns created/overwritten:
    priority_US, priority_RU, priority_CN

Assumes that bloc/type/role have already been reconstructed (e.g., via
inject_military_structured_fields.py), but will fall back to parsing 'notes'
if needed for robustness.
"""

import os
import re
import shutil
from typing import Optional

import pandas as pd

BASE_DIR = os.path.dirname(__file__)
DATAMAP_DIR = os.path.join(BASE_DIR, "dataMap")
DATA_DIR = os.path.join(DATAMAP_DIR, "data")
PROCESSED_DIR = os.path.join(DATA_DIR, "processed")

MASTER_PATH = os.path.join(PROCESSED_DIR, "data.csv")
BACKUP_PATH = os.path.join(PROCESSED_DIR, "data_without_priority_backup.csv")

NOTES_PATTERN = re.compile(
    r"^\s*Bloc:\s*(?P<bloc>.*?);\s*"
    r"Type:\s*(?P<type>.*?);\s*"
    r"Role:\s*(?P<role>.*?);\s*"
    r"Notes:\s*(?P<notes>.*)\s*$",
    re.IGNORECASE,
)


def _clean(v: Optional[str]) -> str:
    if v is None:
        return ""
    return str(v).strip()


def parse_notes_for_type_role(cell):
    """Best-effort parse of type/role from a flattened notes string."""
    if not isinstance(cell, str):
        return None, None
    txt = cell.strip()
    m = NOTES_PATTERN.match(txt)
    if not m:
        return None, None
    type_ = _clean(m.group("type"))
    role = _clean(m.group("role"))
    if type_.lower() == "nan":
        type_ = ""
    if role.lower() == "nan":
        role = ""
    return type_ or None, role or None


def classify_priority(type_val, role_val, importance_val, notes_val) -> int:
    """
    Map (type, role, importance, notes) to an integer priority [0..5].

    This is intentionally simple & easy to tweak. Right now, it is symmetric
    for US/RU/CN; if you want attacker-specific behavior later, you can split
    this out by attacker.
    """
    t = _clean(type_val).upper()
    r = _clean(role_val).upper()
    notes = _clean(notes_val).upper()

    # Normalize importance (often 3 or 5 in your curated data)
    try:
        imp = float(importance_val)
    except Exception:
        imp = 3.0

    # Nuclear / strategic assets
    if "SSBN" in r or "SSBN" in t or "SSBN" in notes:
        return 5
    if "ICBM" in r or "ICBM" in t or "MISSILE" in t or "MISSILE" in r:
        return 5
    if "NUCLEAR" in notes:
        return 5

    # Strong command & control, top-tier air/naval bases
    if t in {"COMMAND", "C2", "C3I", "STRATEGIC_COMMAND"}:
        return 5
    if t in {"AIRBASE", "NAVAL_BASE"} and imp >= 5:
        return 5

    # Important operational air/naval bases
    if t in {"AIRBASE", "NAVAL_BASE"}:
        return 4

    # Early warning / radar / significant sensing
    if t in {"RADAR", "EARLY_WARNING", "EW"}:
        return 3

    # Logistics, depots, training, misc
    if t in {"LOGISTICS", "DEPOT", "TRAINING", "SUPPORT"}:
        return 2

    # Fallback: use importance as a hint
    if imp >= 5:
        return 4
    if imp >= 4:
        return 3
    if imp >= 3:
        return 2

    # Default low priority
    return 1


def main():
    if not os.path.exists(MASTER_PATH):
        raise FileNotFoundError(f"Master data file not found at {MASTER_PATH}")

    print(f"[Paths] Master: {MASTER_PATH}")
    print(f"[Paths] Backup: {BACKUP_PATH}")

    df = pd.read_csv(MASTER_PATH, low_memory=False)
    print(f"[Load] Loaded {len(df):,} rows with {len(df.columns)} columns.")

    if "source_layer" not in df.columns:
        raise RuntimeError("Expected column 'source_layer' not found.")

    mil_mask = df["source_layer"] == "military_master"
    num_mil = mil_mask.sum()
    print(f"[Filter] Identified {num_mil:,} military_master rows.")

    if num_mil == 0:
        print("[Info] No military_master rows; nothing to do.")
        return

    # Ensure priority columns exist
    for col in ["priority_US", "priority_RU", "priority_CN"]:
        if col not in df.columns:
            df[col] = 0

    # Prepare working view
    mil_df = df.loc[mil_mask].copy()

    # If 'type' or 'role' missing/empty, try to recover from notes
    if "type" not in mil_df.columns:
        mil_df["type"] = pd.NA
    if "role" not in mil_df.columns:
        mil_df["role"] = pd.NA

    print("[Recover] Filling missing type/role from notes where possible...")
    parsed_tr = mil_df.apply(
        lambda row: parse_notes_for_type_role(row.get("notes", None)), axis=1
    )
    parsed_type = [p[0] for p in parsed_tr]
    parsed_role = [p[1] for p in parsed_tr]

    # Only fill where current value is null/empty and parsed has something
    for col, parsed in [("type", parsed_type), ("role", parsed_role)]:
        current = mil_df[col].astype(str)
        mask_empty = current.isna() | (current.str.strip() == "") | (current.str.lower() == "nan")
        parsed_series = pd.Series(parsed, index=mil_df.index)
        mask_parsed = parsed_series.notna()
        to_update = mask_empty & mask_parsed
        num_update = to_update.sum()
        print(f"[Recover] Updated {num_update:,} '{col}' values from notes.")
        mil_df.loc[to_update, col] = parsed_series[to_update]

    # Compute priority
    print("[Priority] Computing priority scores for military rows...")
    mil_df["__priority"] = mil_df.apply(
        lambda row: classify_priority(
            row.get("type", None),
            row.get("role", None),
            row.get("importance", None),
            row.get("notes", None),
        ),
        axis=1,
    )

    # Simple symmetric mapping: same priority for all three attackers for now.
    for col in ["priority_US", "priority_RU", "priority_CN"]:
        df.loc[mil_mask, col] = mil_df["__priority"].astype(int)

    # Backup original without priority once
    if not os.path.exists(BACKUP_PATH):
        print(f"[Backup] Creating backup at {BACKUP_PATH}")
        shutil.copy2(MASTER_PATH, BACKUP_PATH)
    else:
        print(f"[Backup] Backup already exists at {BACKUP_PATH}")

    # Some stats
    print("[Stats] priority_US value counts:")
    print(df.loc[mil_mask, "priority_US"].value_counts(dropna=False).sort_index().to_string())

    # Example: type x priority crosstab (small preview)
    if "type" in mil_df.columns:
        ct = pd.crosstab(mil_df["type"].astype(str), mil_df["__priority"]).sort_index()
        print("[Stats] Crosstab type x priority (first 40 rows):")
        print(ct.head(40).to_string())

    # Write updated master
    df.to_csv(MASTER_PATH, index=False)
    print(f"[Write] Updated master with priority columns at {MASTER_PATH}")


if __name__ == "__main__":
    main()

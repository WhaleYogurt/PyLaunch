#!/usr/bin/env python
"""
fast_world_strike_animation_map.py

Builds a Folium map with time-slider animation for nuclear strikes
from:
    dataMap/data/processed/strike_animation_US_RU_GLOBAL.json

Output:
    dataMap/strike_animation_map.html

Behavior:
- ONE TimeDimension layer (TimestampedGeoJson) for both:
    * missile arcs (LineString with times[] per coordinate)
    * impact markers (Point with impact time)
- Leaflet.TimeDimension makes the line "grow" over time with a head marker.
- Static launch markers at origin locations using emoji icons based on delivery_system:
    ICBM / UNKNOWN -> 🚀
    SLBM           -> 🚢
    BOMBER         -> ✈️
- Casualty model + remaining-population time series:
  * Reads city populations from dataMap/data/processed/data.csv
    using either 'city' or 'name' for city name.
  * Uses population + yield + target_type to estimate casualties per strike.
  * Tracks remaining per-city population (avoids double-counting).
  * Builds a time series of remaining global population over impact times.
- THEN rescales that curve so it starts at DISPLAY_WORLD_POP (8 billion)
  and depletes at the same fractional rate.
- Adds a simple post-war model over 1 year:
    * Additional deaths per day depend on:
        - Power grid fraction (dynamic over time)
        - Global radiation index (dynamic over time)
- Adds a fixed panel (top-right) with:
    * Remaining population
    * Death count in red
    * Grid remaining (%) – changes over time
    * Radiation index (0–100) – changes over time
    * SVG line graph of remaining population vs time.
- Adds a static radiation heatmap layer built from strike impacts & yields.

Test mode:
    python fast_world_strike_animation_map.py --test
  → limit to 5 missiles per wave to reduce lag.
"""

import os
import json
import random
import sys
from datetime import datetime, timedelta

import folium
from folium.plugins import TimestampedGeoJson, HeatMap


# -------------------------------
# Paths
# -------------------------------

BASE_DIR = os.path.dirname(__file__)
DATAMAP_DIR = os.path.join(BASE_DIR, "dataMap")
DATA_DIR = os.path.join(DATAMAP_DIR, "data")
PROCESSED_DIR = os.path.join(DATA_DIR, "processed")

ANIMATION_PATH = os.path.join(PROCESSED_DIR, "strike_animation_US_RU_GLOBAL.json")
MASTER_DATA_PATH = os.path.join(PROCESSED_DIR, "data.csv")
OUTPUT_MAP_PATH = os.path.join(DATAMAP_DIR, "strike_animation_map.html")


# -------------------------------
# Config / styling
# -------------------------------

# Color by attacker
ATTACKER_COLORS = {
    "UnitedStates": "#3388ff",  # blue
    "Russia": "#ff3333",        # red
    "China": "#33ff99",         # future use
}

DEFAULT_COLOR = "#aaaaaa"

# Wave → dash pattern (visual hint)
WAVE_DASHES = {
    "wave1": "5,0",   # solid
    "wave2": "10,5",  # dashed
    "wave3": "2,8",   # dotted
}

# Wave → jitter window (in hours) added around that wave's anchor
WAVE_LAUNCH_WINDOWS = {
    "wave1": (0.0, 2.0),   # 0–2 h
    "wave2": (0.0, 4.0),   # 6–10 h around wave2 anchor (6 h)
    "wave3": (0.0, 4.0),   # 24–28 h around wave3 anchor (24 h)
}

# Seed for reproducible randomness; change/remove if you want different jitter each run
random.seed(42)

# Test mode flag (CLI: --test)
TEST_MODE = "--test" in sys.argv
TEST_MAX_PER_WAVE = 5

# World population for display (regardless of glitches in the dataset)
DISPLAY_WORLD_POP = 8_000_000_000

# Post-war modeling horizon (days) after last impact
POSTWAR_DAYS = 365

# Parameters for post-war additional mortality
BASE_POSTWAR_DAILY_MORTALITY = 0.0005  # baseline daily fraction of survivors at high stress
GRID_SENSITIVITY = 2.0                 # how strongly dead_fraction erodes grid
GRID_MIN_FRACTION = 0.05               # minimum grid fraction
RADIATION_WEIGHT = 0.5                 # weight of radiation index in extra deaths

# Radiation decay (global, crude)
RADIATION_DECAY_HALF_LIFE_DAYS = 30.0
RADIATION_DECAY_LAMBDA = 0.693 / (RADIATION_DECAY_HALF_LIFE_DAYS * 24.0)  # per hour


# -------------------------------
# Population / casualty model
# -------------------------------

def load_population_model():
    """
    Load city populations from data.csv.

    Returns:
        (city_pop_map, world_pop_estimate)

        city_pop_map: { (country.lower(), city.lower()): population_float }
                      city comes from 'city' if available, else 'name'
        world_pop_estimate: int, ~total world population from those rows

    On failure, returns ({}, 8_000_000_000).
    """
    city_pop = {}
    world_pop = 8_000_000_000  # fallback

    try:
        import pandas as pd
    except ImportError:
        print("[Pop] pandas not available; using rough world population only.")
        return city_pop, world_pop

    if not os.path.exists(MASTER_DATA_PATH):
        print(f"[Pop] data.csv not found at {MASTER_DATA_PATH}; using rough world population only.")
        return city_pop, world_pop

    try:
        df = pd.read_csv(MASTER_DATA_PATH, low_memory=False)
    except Exception as e:
        print(f"[Pop] Failed to read data.csv: {e}; using rough world population only.")
        return city_pop, world_pop

    if "population" not in df.columns:
        print("[Pop] 'population' column not found in data.csv; using rough world population only.")
        return city_pop, world_pop

    # Restrict to city-like rows to avoid weird totals
    city_mask = False
    if "source_layer" in df.columns:
        city_mask = (df["source_layer"].astype(str).str.lower() == "cities")
    if "target_class" in df.columns:
        tc_mask = df["target_class"].astype(str).str.upper() == "CITY"
        city_mask = city_mask | tc_mask

    if city_mask is False:
        city_df = df
    else:
        city_df = df[city_mask]

    try:
        import pandas as pd  # to use to_numeric
        pop_series = pd.to_numeric(city_df["population"], errors="coerce")
        pop_series = pop_series[pop_series > 0]
        total = float(pop_series.sum())
        if 1e9 < total < 2e10:
            world_pop = int(total)
        else:
            world_pop = 8_000_000_000
    except Exception:
        world_pop = 8_000_000_000

    # Build city map
    has_city_col = "city" in city_df.columns
    has_name_col = "name" in city_df.columns

    for _, row in city_df.iterrows():
        raw_city = ""
        if has_city_col:
            raw_city = row.get("city", "")
        if (not raw_city) and has_name_col:
            raw_city = row.get("name", "")

        city = str(raw_city).strip()
        country = str(row.get("country", "")).strip()
        if not city or not country:
            continue

        try:
            pop_val = float(row.get("population", 0))
        except Exception:
            continue
        if pop_val <= 0:
            continue

        key = (country.lower(), city.lower())
        if key in city_pop:
            if pop_val > city_pop[key]:
                city_pop[key] = pop_val
        else:
            city_pop[key] = pop_val

    print(f"[Pop] Loaded {len(city_pop):,} city populations; world_pop ≈ {world_pop:,}.")
    return city_pop, world_pop


def estimate_casualties(strike, city_pop_map, city_remaining_map):
    """
    Rough casualty estimate per strike.

    - For city targets with known population:
        casualties = frac * remaining_city_pop
        frac ~ 0.5 * (yield / 500 kt)^0.3, capped at 1.0
    - For military targets:
        casualties ~ 20k * (yield / 100 kt)^0.3
    - For other/unknown:
        casualties ~ 50k * (yield / 100 kt)^0.3

    city_remaining_map is updated for city targets to avoid double-counting deaths.
    """
    target_type = (strike.get("target_type") or "").lower()
    to = strike.get("to", {})
    country = str(to.get("country", "")).strip().lower()
    city = str(to.get("city", "")).strip().lower()

    key = (country, city) if country and city else None
    pop_city = city_pop_map.get(key) if key else None

    # Remaining population for this city (if we track it)
    if key and key in city_remaining_map:
        pop_remaining = city_remaining_map[key]
    else:
        pop_remaining = pop_city

    # Yields
    yield_kt = strike.get("expected_effective_yield_kt") or strike.get("yield_mean_kt") or 100.0
    try:
        yield_kt = float(yield_kt)
    except Exception:
        yield_kt = 100.0

    if target_type == "city" and pop_remaining and pop_remaining > 0:
        frac = min(1.0, 0.5 * (yield_kt / 500.0) ** 0.3)
        casualties = int(pop_remaining * frac)
        if key:
            city_remaining_map[key] = max(0.0, pop_remaining - casualties)
        return max(0, casualties)

    elif target_type == "military":
        base = 20_000.0 * (yield_kt / 100.0) ** 0.3
        return int(base)

    else:
        base = 50_000.0 * (yield_kt / 100.0) ** 0.3
        return int(base)


# -------------------------------
# Visualization helpers
# -------------------------------

def _extract_arc_points_with_tfrac(strike):
    """
    Get a list of (lat, lon, t_frac) from strike["arc_points"].

    Handles:
      - arc_points = [{"lat": .., "lon": .., "t_frac": ..}, ...]  (preferred)
      - arc_points = [[lat, lon], ...]                            (fallback: infer t_frac)
    """
    arc_points = strike.get("arc_points") or []
    result = []

    if not arc_points:
        from_pt = strike.get("from", {})
        to_pt = strike.get("to", {})
        try:
            o_lat = float(from_pt["lat"])
            o_lon = float(from_pt["lon"])
            t_lat = float(to_pt["lat"])
            t_lon = float(to_pt["lon"])
        except (KeyError, TypeError, ValueError):
            return []
        return [
            (o_lat, o_lon, 0.0),
            (t_lat, t_lon, 1.0),
        ]

    first = arc_points[0]
    if isinstance(first, dict):
        for p in arc_points:
            try:
                lat = float(p["lat"])
                lon = float(p["lon"])
                t_frac = float(p.get("t_frac", 0.0))
            except (KeyError, TypeError, ValueError):
                continue
            t_frac = max(0.0, min(1.0, t_frac))
            result.append((lat, lon, t_frac))
    else:
        n = len(arc_points)
        if n < 2:
            return []
        for i, p in enumerate(arc_points):
            try:
                lat, lon = float(p[0]), float(p[1])
            except (TypeError, ValueError, IndexError):
                continue
            t_frac = i / (n - 1)
            result.append((lat, lon, t_frac))

    return result


def _build_popup_html(strike) -> str:
    """
    Build a small HTML popup for a strike.
    """
    attacker = strike.get("attacker", "Unknown")
    wave = strike.get("wave", "wave?")
    target_type = strike.get("target_type", "city")
    delivery = strike.get("delivery_system", "UNKNOWN")

    to_info = strike.get("to", {})
    city = to_info.get("city", "Unknown")
    country = to_info.get("country", "Unknown")

    yield_class = strike.get("yield_class", "unknown")
    warheads = strike.get("warheads_per_strike", 1)
    distance_km = strike.get("distance_km", 0.0)
    wave_time = strike.get("wave_time_hours", 0.0)
    impact_time = strike.get("impact_time_hours", None)

    s = []
    s.append(f"<b>Attacker:</b> {attacker}<br>")
    s.append(f"<b>Wave:</b> {wave}<br>")
    s.append(f"<b>Target:</b> {city}, {country} ({target_type})<br>")
    s.append(f"<b>Delivery:</b> {delivery}<br>")
    s.append(f"<b>Yield class:</b> {yield_class}<br>")
    s.append(f"<b>Warheads:</b> {warheads}<br>")
    s.append(f"<b>Distance:</b> {distance_km:.0f} km<br>")
    s.append(f"<b>Wave anchor (t):</b> {wave_time:.1f} h<br>")
    if impact_time is not None:
        try:
            impact = float(impact_time)
            s.append(f"<b>Impact (t, approx):</b> {impact:.1f} h<br>")
        except (TypeError, ValueError):
            pass
    return "".join(s)


def _build_line_style(attacker: str, wave: str) -> dict:
    """
    Style for the arc (line) itself.
    """
    color = ATTACKER_COLORS.get(attacker, DEFAULT_COLOR)
    wave = (wave or "").lower()
    dash = WAVE_DASHES.get(wave, "5,0")

    return {
        "color": color,
        "weight": 2,
        "opacity": 0.85,
        "dashArray": dash,
    }


def _simulation_time_to_iso(base_dt: datetime, sim_hours: float) -> str:
    """
    Convert simulation hours (t=0 at scenario start) to ISO8601 string
    for the time slider.
    """
    return (base_dt + timedelta(hours=float(sim_hours or 0.0))).isoformat() + "Z"


def _get_random_launch_time_hours(wave_name: str, wave_anchor: float) -> float:
    """
    Given wave name and its anchor (wave_time_hours from scenario),
    return a jittered launch time within a wave-specific window.
    """
    wave_name = (wave_name or "").lower()
    window = WAVE_LAUNCH_WINDOWS.get(wave_name, (0.0, 2.0))
    offset = random.uniform(window[0], window[1])
    return wave_anchor + offset


def _launch_emoji(delivery_system: str) -> str:
    """
    Choose an emoji for the launch location based on delivery_system.
    """
    ds = (delivery_system or "UNKNOWN").upper()
    if ds == "SLBM":
        return "🚢"
    if ds == "BOMBER":
        return "✈️"
    # ICBM + UNKNOWN
    return "🚀"


# -------------------------------
# Main
# -------------------------------

def main():
    print(f"[Paths] Animation JSON: {ANIMATION_PATH}")
    print(f"[Paths] Output map:      {OUTPUT_MAP_PATH}")
    if TEST_MODE:
        print("[Mode] TEST MODE ENABLED: limiting to 5 missiles per wave.")

    if not os.path.exists(ANIMATION_PATH):
        raise FileNotFoundError(f"Animation data file not found at {ANIMATION_PATH}")

    with open(ANIMATION_PATH, "r", encoding="utf-8") as f:
        anim_data = json.load(f)

    strikes = anim_data.get("strikes", [])
    print(f"[Load] Loaded {len(strikes):,} strikes from animation JSON.")

    if not strikes:
        raise RuntimeError("No strikes found in animation JSON.")

    # Optional test mode: limit number of missiles per wave
    if TEST_MODE:
        per_wave_counts = {}
        filtered = []
        for s in strikes:
            wave = (s.get("wave") or "").lower()
            c = per_wave_counts.get(wave, 0)
            if c < TEST_MAX_PER_WAVE:
                filtered.append(s)
                per_wave_counts[wave] = c + 1
        print(f"[Test] Keeping {len(filtered)} strikes (<= {TEST_MAX_PER_WAVE} per wave).")
        strikes = filtered

    # Load population model (only for SHAPE of casualty curve)
    city_pop_map, world_pop_est = load_population_model()
    city_remaining_map = dict(city_pop_map)
    print(f"[Pop] Using world population estimate (for fraction only): {world_pop_est:,}")
    print(f"[Pop] Display world population fixed at: {DISPLAY_WORLD_POP:,}")

    # All features (lines + impacts) for a single TimestampedGeoJson
    features = []

    # Launch location info for static markers
    launch_markers = []

    # Track jittered launch times for legend
    launch_times_sim = []

    # Track impact events for population time series & radiation
    impact_events = []  # list of {"t": impact_time_hours, "casualties": int, "yield_kt": float, "lat":, "lon":}

    # For radiation static heatmap
    radiation_points_for_heatmap = []

    # Rough center of targets
    lat_sum = 0.0
    lon_sum = 0.0
    lat_count = 0

    # Base datetime for t=0 (purely arbitrary)
    base_datetime = datetime(2030, 1, 1, 0, 0, 0)

    for s in strikes:
        attacker = s.get("attacker", "Unknown")
        wave = s.get("wave", "wave?")
        delivery = s.get("delivery_system", "UNKNOWN")

        # Jittered launch time
        wave_anchor = float(s.get("wave_time_hours", 0.0))
        launch_time_h = _get_random_launch_time_hours(wave, wave_anchor)
        launch_times_sim.append(launch_time_h)

        # Travel time in hours
        total_travel_minutes = float(s.get("total_travel_time_minutes", 0.0))
        travel_time_h = total_travel_minutes / 60.0 if total_travel_minutes > 0 else 0.0
        impact_time_h = launch_time_h + travel_time_h

        arc_pts = _extract_arc_points_with_tfrac(s)
        if len(arc_pts) < 2:
            continue

        # For centering: use target
        to_pt = s.get("to", {})
        try:
            t_lat = float(to_pt["lat"])
            t_lon = float(to_pt["lon"])
            lat_sum += t_lat
            lon_sum += t_lon
            lat_count += 1
        except (KeyError, TypeError, ValueError):
            t_lat = None
            t_lon = None

        popup_html = _build_popup_html(s)
        line_style = _build_line_style(attacker, wave)

        # --- Line feature (one per missile) ---
        line_coords = []
        line_times = []

        for lat, lon, f in arc_pts:
            f_clamped = max(0.0, min(1.0, float(f)))
            t_h = launch_time_h + f_clamped * travel_time_h
            line_coords.append([lon, lat])  # [lon, lat]
            line_times.append(_simulation_time_to_iso(base_datetime, t_h))

        line_feature = {
            "type": "Feature",
            "geometry": {
                "type": "LineString",
                "coordinates": line_coords,
            },
            "properties": {
                "times": line_times,
                "style": line_style,
                "popup": popup_html,
                "tooltip": f"{attacker} {wave}",
            },
        }
        features.append(line_feature)

        # --- Impact feature (Point at target, appears at impact time) ---
        if t_lat is not None and t_lon is not None:
            impact_iso = _simulation_time_to_iso(base_datetime, impact_time_h)
            impact_popup = "<b>Impact</b><br>" + popup_html

            impact_feature = {
                "type": "Feature",
                "geometry": {
                    "type": "Point",
                    "coordinates": [t_lon, t_lat],
                },
                "properties": {
                    "times": [impact_iso],
                    "style": {
                        "color": "#990000",
                        "fillColor": "#ff0000",
                        "fillOpacity": 0.95,
                        "radius": 6,
                    },
                    "popup": impact_popup,
                },
            }
            features.append(impact_feature)

        # --- Launch marker info (static) ---
        from_pt = s.get("from", {})
        try:
            o_lat = float(from_pt["lat"])
            o_lon = float(from_pt["lon"])
        except (KeyError, TypeError, ValueError):
            o_lat = None
            o_lon = None

        if o_lat is not None and o_lon is not None:
            launch_label = from_pt.get("label", "")
            emoji = _launch_emoji(delivery)

            launch_markers.append(
                {
                    "lat": o_lat,
                    "lon": o_lon,
                    "emoji": emoji,
                    "attacker": attacker,
                    "wave": wave,
                    "label": launch_label,
                }
            )

        # --- Casualty model for this strike (impact time based) ---
        casualties = estimate_casualties(s, city_pop_map, city_remaining_map)

        # Yield for radiation model
        yield_kt = s.get("expected_effective_yield_kt") or s.get("yield_mean_kt") or 100.0
        try:
            yield_kt = float(yield_kt)
        except Exception:
            yield_kt = 100.0

        # Record for casualties & radiation
        impact_events.append(
            {
                "t": impact_time_h,
                "casualties": int(max(0, casualties)),
                "yield_kt": yield_kt,
                "lat": t_lat,
                "lon": t_lon,
            }
        )

        # For static radiation heatmap: weight ~ sqrt(yield / 50)
        if t_lat is not None and t_lon is not None:
            rad_weight = max(1.0, (yield_kt / 50.0) ** 0.5)
            radiation_points_for_heatmap.append([t_lat, t_lon, rad_weight])

    if not features:
        raise RuntimeError("No features generated for animation.")

    fc = {
        "type": "FeatureCollection",
        "features": features,
    }

    # Compute a reasonable map center
    if lat_count > 0:
        center_lat = lat_sum / lat_count
        center_lon = lon_sum / lat_count
    else:
        center_lat, center_lon = 20.0, 0.0  # fallback global center

    # Simulation time range for legend/diagnostics
    min_launch = min(launch_times_sim) if launch_times_sim else 0.0
    max_launch = max(launch_times_sim) if launch_times_sim else 0.0
    print(f"[Time] Jittered launch times: min={min_launch:.2f} h, max={max_launch:.2f} h")

    # ---------------------------
    # Build population time series (raw, using world_pop_est) – DIRECT WAR ONLY
    # ---------------------------
    pop_series_raw = []
    remaining_raw = float(world_pop_est) if world_pop_est > 0 else float(DISPLAY_WORLD_POP)

    if impact_events:
        impact_events.sort(key=lambda e: e["t"])
        # Start at t=0 with full population
        pop_series_raw.append({"t": 0.0, "remaining": int(round(remaining_raw))})
        for evt in impact_events:
            t_evt = evt["t"]
            if t_evt < pop_series_raw[-1]["t"]:
                t_evt = pop_series_raw[-1]["t"]
            remaining_raw = max(0.0, remaining_raw - evt["casualties"])
            pop_series_raw.append({"t": t_evt, "remaining": int(round(remaining_raw))})
    else:
        # No impacts? Just a flat line
        pop_series_raw = [
            {"t": 0.0, "remaining": int(round(remaining_raw))},
            {"t": max_launch if max_launch > 0 else 1.0, "remaining": int(round(remaining_raw))},
        ]

    # Ensure at least two points
    if len(pop_series_raw) < 2:
        pop_series_raw.append({"t": (max_launch if max_launch > 0 else 1.0), "remaining": int(round(remaining_raw))})

    # Time of last impact
    last_impact_t = pop_series_raw[-1]["t"]

    # ---------------------------
    # Rescale DIRECT series to DISPLAY_WORLD_POP
    # ---------------------------
    if world_pop_est > 0:
        scale = DISPLAY_WORLD_POP / float(world_pop_est)
    else:
        scale = 1.0

    pop_series_direct = []
    for i, pt in enumerate(pop_series_raw):
        if i == 0:
            rem = DISPLAY_WORLD_POP
        else:
            val = int(round(pt["remaining"] * scale))
            rem = max(0, val)
        pop_series_direct.append({"t": pt["t"], "remaining": rem})

    # ---------------------------
    # Build global radiation index over time (symbolic, 0 at t=0)
    # ---------------------------
    radiation_series = []
    if impact_events:
        t_end = last_impact_t + POSTWAR_DAYS * 24.0
        dt_hours = 24.0  # daily sampling
        t = 0.0
        while t <= t_end + 0.1:
            total_rad = 0.0
            for evt in impact_events:
                ti = evt["t"]
                if t < ti:
                    continue
                dt = t - ti
                total_rad += evt["yield_kt"] * (2.71828 ** (-RADIATION_DECAY_LAMBDA * dt))
            radiation_series.append({"t": t, "index_raw": total_rad})
            t += dt_hours
    else:
        radiation_series = [{"t": 0.0, "index_raw": 0.0}]

    max_rad = max((r["index_raw"] for r in radiation_series), default=1.0)
    if max_rad <= 0:
        max_rad = 1.0
    for r in radiation_series:
        r["index"] = r["index_raw"] / max_rad

    # ---------------------------
    # Extend population series with POST-WAR deaths over POSTWAR_DAYS
    # ---------------------------
    # Starting from direct survivors at last_impact_t
    postwar_series = []
    survivors = float(pop_series_direct[-1]["remaining"])
    t = last_impact_t
    dt_hours = 24.0
    t_end_post = last_impact_t + POSTWAR_DAYS * 24.0

    # Helpers to get radiation index at arbitrary t
    def get_radiation_index_at(hours: float) -> float:
        if not radiation_series:
            return 0.0
        if hours <= radiation_series[0]["t"]:
            return radiation_series[0]["index"]
        for i in range(1, len(radiation_series)):
            if hours < radiation_series[i]["t"]:
                return radiation_series[i - 1]["index"]
        return radiation_series[-1]["index"]

    # Use DIRECT deaths fraction to influence early grid degradation
    direct_start_dead_fraction = 1.0 - (survivors / DISPLAY_WORLD_POP if DISPLAY_WORLD_POP > 0 else 0.0)

    # Build post-war tail
    while t < t_end_post and survivors > 0:
        t += dt_hours
        rad_index = get_radiation_index_at(t)

        # Approximate dead fraction including post-war so far
        dead_fraction_total = 1.0 - (survivors / DISPLAY_WORLD_POP if DISPLAY_WORLD_POP > 0 else 0.0)

        # Grid fraction degrades as deaths accumulate
        grid_fraction = max(
            GRID_MIN_FRACTION,
            1.0 - GRID_SENSITIVITY * dead_fraction_total
        )
        grid_fraction = min(1.0, grid_fraction)

        # Extra daily mortality fraction
        stress_factor = (1.0 - grid_fraction) ** 1.5
        extra_frac = BASE_POSTWAR_DAILY_MORTALITY * (stress_factor + RADIATION_WEIGHT * rad_index)
        extra_frac = max(0.0, min(0.05, extra_frac))  # cap at 5% per day

        daily_deaths = survivors * extra_frac
        survivors = max(0.0, survivors - daily_deaths)
        postwar_series.append({"t": t, "remaining": int(round(survivors))})

    # Merge direct + post-war into unified pop_series
    pop_series = list(pop_series_direct)
    pop_series.extend(postwar_series)

    # ---------------------------
    # Build GRID series from pop_series (dynamic over time)
    # ---------------------------
    grid_series = []
    for pt in pop_series:
        t = pt["t"]
        rem = float(pt["remaining"])
        if DISPLAY_WORLD_POP > 0:
            dead_fraction = max(0.0, min(1.0, 1.0 - rem / DISPLAY_WORLD_POP))
        else:
            dead_fraction = 0.0
        grid_fraction = max(
            GRID_MIN_FRACTION,
            1.0 - GRID_SENSITIVITY * dead_fraction
        )
        grid_fraction = min(1.0, grid_fraction)
        grid_series.append({"t": t, "grid": grid_fraction})

    # ---------------------------
    # Diagnostics
    # ---------------------------
    first_disp = pop_series[0]["remaining"]
    last_disp = pop_series[-1]["remaining"]
    deaths_disp = first_disp - last_disp
    frac_dead_disp = deaths_disp / float(first_disp) if first_disp > 0 else 0.0
    print(f"[Check] Display pop: start={first_disp:,}, end={last_disp:,}, "
          f"deaths={deaths_disp:,} ({frac_dead_disp*100:.2f}% of humanity)")

    # ---------------------------
    # Build the Folium map
    # ---------------------------

    m = folium.Map(
        location=[center_lat, center_lon],
        zoom_start=2,
        tiles="CartoDB positron",
        control_scale=True,
    )

    # Optional: dark basemap layer
    folium.TileLayer(
        "CartoDB dark_matter",
        name="Dark",
        control=True,
    ).add_to(m)

    # TimeDimension layer: arcs + impact points with a single time slider
    ts_layer = TimestampedGeoJson(
        data=fc,
        transition_time=100,      # ms between steps
        loop=False,
        auto_play=False,
        add_last_point=True,      # built-in moving head marker for lines
        period="PT1M",            # 1 minute per slider step → smoother motion
        time_slider_drag_update=True,
        duration=None,            # features persist once drawn
    )
    ts_layer.add_to(m)

    # Static launch markers with emoji icons
    for lm in launch_markers:
        lat = lm["lat"]
        lon = lm["lon"]
        emoji = lm["emoji"]
        attacker = lm["attacker"]
        wave = lm["wave"]
        label = lm["label"] or "(launch)"

        popup_html = (
            f"<b>Launch site</b><br>"
            f"{emoji} {label}<br>"
            f"Attacker: {attacker}<br>"
            f"Wave: {wave}"
        )

        folium.Marker(
            location=[lat, lon],
            popup=popup_html,
            icon=folium.DivIcon(
                html=f'<div style="font-size: 16px; line-height: 16px;">{emoji}</div>'
            ),
        ).add_to(m)

    # Radiation heatmap (static, time-averaged intensity at impact points)
    if radiation_points_for_heatmap:
        heat_data = [[lat, lon, w] for (lat, lon, w) in radiation_points_for_heatmap]
        HeatMap(
            data=heat_data,
            name="Radiation hotspots (static)",
            radius=25,
            blur=35,
            max_zoom=6,
        ).add_to(m)

    # Add layer control
    folium.LayerControl(collapsed=True).add_to(m)

    # Legend (moved up so it doesn't cover controls)
    legend_html = f"""
    <div style="
        position: fixed;
        bottom: 250px;
        left: 50px;
        z-index: 9999;
        background-color: rgba(255, 255, 255, 0.85);
        padding: 10px 12px;
        border-radius: 6px;
        box-shadow: 0 0 5px rgba(0,0,0,0.3);
        font-size: 13px;
    ">
      <div style="font-weight: bold; margin-bottom: 4px;">Strike Arcs & Impacts</div>
      <div><span style="display:inline-block;width:12px;height:3px;background:#3388ff;margin-right:6px;"></span>United States</div>
      <div><span style="display:inline-block;width:12px;height:3px;background:#ff3333;margin-right:6px;"></span>Russia</div>
      <div style="margin-top:4px;">Launch icons: 🚀 ICBM / 🚢 SLBM / ✈️ Bomber</div>
      <div style="margin-top:4px;">Overlay: Radiation hotspots (static heatmap)</div>
      <div style="margin-top:6px;font-size:11px;">
        Time slider: launches from t ≈ {min_launch:.1f} h to t ≈ {max_launch:.1f} h,
        post-war modeled for {POSTWAR_DAYS} days.
      </div>
      {"<div style='margin-top:4px;font-size:11px;color:#aa0000;'>TEST MODE: only 5 missiles per wave.</div>" if TEST_MODE else ""}
    </div>
    """
    m.get_root().html.add_child(folium.Element(legend_html))

    # ---------------------------
    # Remaining population + grid + radiation panel (top-right)
    # ---------------------------
    pop_series_js = json.dumps(pop_series)
    grid_series_js = json.dumps(grid_series)
    rad_series_js = json.dumps(radiation_series)

    base_datetime_iso = base_datetime.isoformat() + "Z"
    initial_remaining = pop_series[0]["remaining"] if pop_series else DISPLAY_WORLD_POP

    graph_html = """
    <div id="radmap-pop-container" style="
        position: fixed;
        top: 10px;
        right: 10px;
        z-index: 9999;
        background-color: rgba(255, 255, 255, 0.9);
        padding: 8px 10px;
        border-radius: 6px;
        box-shadow: 0 0 5px rgba(0,0,0,0.3);
        font-size: 12px;
        max-width: 280px;
    ">
      <div style="font-weight:bold; font-size:13px;">Post-war humanity</div>
      <div id="radmap-pop-display" style="font-size:16px; margin:4px 0 0 0;">...</div>
      <div id="radmap-death-display" style="font-size:13px; margin:0 0 2px 0; color:#aa0000;">...</div>
      <div id="radmap-grid-display" style="font-size:12px; margin:2px 0;">
        Grid remaining: <span id="radmap-grid-val">...</span>%
      </div>
      <div id="radmap-rad-display" style="font-size:12px; margin:0 0 4px 0;">
        Radiation index: <span id="radmap-rad-val">...</span>/100
      </div>
      <svg id="radmap-pop-svg" width="260" height="80">
        <path id="radmap-pop-path" d="" stroke="#333" stroke-width="2" fill="none" />
      </svg>
    </div>
    """

    script_vars = f"""
    <script>
    var radmapBaseDate = new Date("{base_datetime_iso}");
    var radmapTimeSeries = {pop_series_js};
    var radmapGridSeries = {grid_series_js};
    var radmapRadSeries = {rad_series_js};
    var radmapInitialRemaining = {initial_remaining};
    var radmapWorldPopDisplay = {DISPLAY_WORLD_POP};
    </script>
    """

    script_body = """
    <script>
    function radmapFormatPop(n) {
        if (n >= 1e9) return (n / 1e9).toFixed(2) + " B";
        if (n >= 1e6) return (n / 1e6).toFixed(1) + " M";
        if (n >= 1e3) return (n / 1e3).toFixed(0) + " K";
        return Math.round(n).toString();
    }
    function radmapGetRemainingAt(hours) {
        if (!window.radmapTimeSeries || radmapTimeSeries.length === 0) {
            return window.radmapInitialRemaining || 0;
        }
        var series = radmapTimeSeries;
        if (hours <= series[0].t) return series[0].remaining;
        for (var i = 1; i < series.length; i++) {
            if (hours < series[i].t) {
                return series[i - 1].remaining;
            }
        }
        return series[series.length - 1].remaining;
    }
    function radmapGetGridAt(hours) {
        if (!window.radmapGridSeries || radmapGridSeries.length === 0) {
            return 1.0;
        }
        var series = radmapGridSeries;
        if (hours <= series[0].t) return series[0].grid;
        for (var i = 1; i < series.length; i++) {
            if (hours < series[i].t) {
                return series[i - 1].grid;
            }
        }
        return series[series.length - 1].grid;
    }
    function radmapGetRadAt(hours) {
        if (!window.radmapRadSeries || radmapRadSeries.length === 0) {
            return 0.0;
        }
        var series = radmapRadSeries;
        if (hours <= series[0].t) return series[0].index;
        for (var i = 1; i < series.length; i++) {
            if (hours < series[i].t) {
                return series[i - 1].index;
            }
        }
        return series[series.length - 1].index;
    }
    document.addEventListener("DOMContentLoaded", function() {
        var displayEl = document.getElementById("radmap-pop-display");
        var deathEl = document.getElementById("radmap-death-display");
        var pathEl = document.getElementById("radmap-pop-path");
        var gridEl = document.getElementById("radmap-grid-val");
        var radEl = document.getElementById("radmap-rad-val");
        var worldPop = window.radmapWorldPopDisplay || 0;

        // Initial values at t=0
        var rem0 = radmapGetRemainingAt(0.0);
        var grid0 = radmapGetGridAt(0.0);
        var rad0 = radmapGetRadAt(0.0);

        if (displayEl) {
            displayEl.textContent = radmapFormatPop(rem0);
        }
        if (deathEl) {
            var d0 = Math.max(0, worldPop - rem0);
            deathEl.textContent = "- " + radmapFormatPop(d0) + " dead";
        }
        if (gridEl) {
            gridEl.textContent = (grid0 * 100).toFixed(1);
        }
        if (radEl) {
            radEl.textContent = Math.round(rad0 * 100);
        }

        // Draw population curve (full time span, including post-war)
        if (pathEl && window.radmapTimeSeries && radmapTimeSeries.length > 0) {
            var svgWidth = 260;
            var svgHeight = 80;
            var minT = radmapTimeSeries[0].t;
            var maxT = radmapTimeSeries[radmapTimeSeries.length - 1].t;
            if (maxT <= minT) maxT = minT + 1.0;
            var maxPop = radmapTimeSeries[0].remaining;
            var minPop = radmapTimeSeries[radmapTimeSeries.length - 1].remaining;
            if (maxPop <= minPop) maxPop = minPop + 1.0;
            var cmds = "";
            for (var i = 0; i < radmapTimeSeries.length; i++) {
                var t = radmapTimeSeries[i].t;
                var rem = radmapTimeSeries[i].remaining;
                var x = (t - minT) / (maxT - minT) * (svgWidth - 10) + 5;
                var y = (1.0 - (rem - minPop) / (maxPop - minPop)) * (svgHeight - 20) + 10;
                cmds += (i === 0 ? "M" : "L") + x.toFixed(1) + " " + y.toFixed(1) + " ";
            }
            pathEl.setAttribute("d", cmds);
        }

        // Hook into Leaflet.TimeDimension for live updates
        var mapObj = null;
        for (var key in window) {
            if (window[key] && window[key] instanceof L.Map) {
                mapObj = window[key];
                break;
            }
        }
        if (!mapObj || !mapObj.timeDimension) {
            return;
        }
        var td = mapObj.timeDimension;
        td.on("timeload", function(e) {
            if (!displayEl) return;
            var currentTime = e.time;
            var baseMs = radmapBaseDate.getTime();
            var simHours = (currentTime - baseMs) / 3600000.0;

            var rem = radmapGetRemainingAt(simHours);
            var grid = radmapGetGridAt(simHours);
            var radIdx = radmapGetRadAt(simHours);

            displayEl.textContent = radmapFormatPop(rem);

            if (deathEl) {
                var deaths = Math.max(0, worldPop - rem);
                deathEl.textContent = "- " + radmapFormatPop(deaths) + " dead";
            }
            if (gridEl) {
                gridEl.textContent = (grid * 100).toFixed(1);
            }
            if (radEl) {
                radEl.textContent = Math.round(radIdx * 100);
            }
        });
    });
    </script>
    """

    m.get_root().html.add_child(folium.Element(graph_html + script_vars + script_body))

    # Save map
    os.makedirs(DATAMAP_DIR, exist_ok=True)
    m.save(OUTPUT_MAP_PATH)
    print(f"[Output] Wrote strike animation map to {OUTPUT_MAP_PATH}")


if __name__ == "__main__":
    main()

import json
import csv
from pathlib import Path

# Where your GeoJSONs are stored
BASE = Path("data/processed")

OUTFILE = BASE / "all_osm_targets.csv"

# Folders we extracted earlier
CATEGORIES = ["industrial", "military"]

def extract_features(geojson_path, region, category):
    """Load features from a GeoJSON and extract coords + tags."""
    with open(geojson_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    for feature in data.get("features", []):
        props = feature.get("properties", {})
        geom = feature.get("geometry", {})

        # Skip anything without a point or polygon center
        if geom.get("type") == "Point":
            lon, lat = geom["coordinates"]
        elif geom.get("type") == "Polygon":
            lon, lat = geom["coordinates"][0][0]
        elif geom.get("type") == "MultiPolygon":
            lon, lat = geom["coordinates"][0][0][0]
        else:
            continue

        row = {
            "region": region,
            "category": category,
            "osm_id": props.get("@id", ""),
            "name": props.get("name", ""),
            "subtype": props.get("industrial") 
                       or props.get("landuse") 
                       or props.get("military")
                       or props.get("man_made")
                       or "",
            "lat": lat,
            "lon": lon,
            "tags": json.dumps(props, ensure_ascii=False)
        }

        yield row


def main():
    rows = []

    print("\nCombining GeoJSON files...")

    for category in CATEGORIES:
        folder = BASE / category
        files = list(folder.glob("*.geojson"))

        for geojson_file in files:
            region_name = geojson_file.stem.replace(f"_{category}", "")

            print(f" → Reading {geojson_file} ...")

            for row in extract_features(geojson_file, region_name, category):
                rows.append(row)

    print(f"\nWriting CSV → {OUTFILE} ...")

    with open(OUTFILE, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "region", "category", "osm_id", "name",
            "subtype", "lat", "lon", "tags"
        ])
        writer.writeheader()
        writer.writerows(rows)

    print(f"\nDONE. Wrote {len(rows):,} rows.")
    print(f"CSV ready: {OUTFILE}")


if __name__ == "__main__":
    main()

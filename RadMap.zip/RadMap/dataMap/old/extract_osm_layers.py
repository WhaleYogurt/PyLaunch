#!/usr/bin/env python
"""
extract_osm_layers.py

Extracts industrial and military features from any .osm.pbf files in:

    data/osm/

Outputs (newline-delimited GeoJSON):
    data/processed/industrial/<region>_industrial.ndjson
    data/processed/military/<region>_military.ndjson

Tuning for large machines (e.g. 128 GB RAM):

    - Discovers all *.osm.pbf in data/osm
    - Processes "small/medium" PBFs in parallel
    - Processes "huge" PBFs sequentially (one at a time) to avoid RAM spikes
    - Uses idx='flex_mem' for small/medium, idx='sparse_mem_array' for huge
    - Single streaming pass per file (industrial + military together)
    - Nodes, ways, and relations are all considered for filtering
    - Uses calibration (approx_entities_per_mb) to estimate progress

CLI options:

    --workers N        : override max worker threads for small/medium PBFs
    --index MODE       : 'auto', 'flex_mem', 'sparse_mem_array'
    --no-progress      : disable tqdm progress bars
    --profile          : enable cProfile (off by default)
    --fast             : shorthand for: --no-progress --index auto --workers 3

Requirements:
    pip / conda:
        python-osmium
        tqdm
"""

import json
import re
import os
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

import osmium
from osmium.geom import GeoJSONFactory
from tqdm import tqdm

# ---------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------

# Initial guess; refined automatically via calibration file.
DEFAULT_APPROX_ENTITIES_PER_MB = 25_000

# Threshold (in MB) to treat a PBF as "huge".
# On a 128 GB box, anything above ~12 GB we treat carefully.
HUGE_PBF_THRESHOLD_MB = 12_000  # ≈ 12 GB

# ---------------------------------------------------------------------
# PATHS
# ---------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"

# NOTE: We scan data/osm/*.osm.pbf by default.
OSM_DIR = DATA_DIR / "osm"
PROCESSED_DIR = DATA_DIR / "processed"
OUT_INDUSTRIAL_DIR = PROCESSED_DIR / "industrial"
OUT_MILITARY_DIR = PROCESSED_DIR / "military"

CALIB_PATH = PROCESSED_DIR / "osm_calibration.json"


# ---------------------------------------------------------------------
# CALIBRATION LOAD/SAVE
# ---------------------------------------------------------------------

def load_approx_entities_per_mb() -> int:
    """Load global approx_entities_per_mb from calibration JSON if present."""
    if CALIB_PATH.exists():
        try:
            with CALIB_PATH.open("r", encoding="utf-8") as f:
                data = json.load(f)
            value = int(data.get("approx_entities_per_mb", DEFAULT_APPROX_ENTITIES_PER_MB))
            print(f"[Calibration] Loaded approx_entities_per_mb={value} from {CALIB_PATH}")
            return value
        except Exception as e:
            print(f"[Calibration] Could not load calibration ({e}); using default.")
    else:
        print(f"[Calibration] No calibration file found. Using default {DEFAULT_APPROX_ENTITIES_PER_MB}.")
    return DEFAULT_APPROX_ENTITIES_PER_MB


def save_approx_entities_per_mb(value: int) -> None:
    """Save global approx_entities_per_mb to calibration JSON."""
    CALIB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with CALIB_PATH.open("w", encoding="utf-8") as f:
        json.dump({"approx_entities_per_mb": int(value)}, f, indent=2)
    print(f"[Calibration] Saved approx_entities_per_mb={value} to {CALIB_PATH}")


APPROX_ENTITIES_PER_MB = load_approx_entities_per_mb()


# ---------------------------------------------------------------------
# PBF DISCOVERY & REGION NAMING
# ---------------------------------------------------------------------

def find_pbf_files():
    """Return sorted list of all *.osm.pbf files in data/osm."""
    if not OSM_DIR.exists():
        print(f"[PBF] Directory not found: {OSM_DIR}")
        return []

    files = sorted(OSM_DIR.glob("*.osm.pbf"))
    if not files:
        print("[PBF] No *.osm.pbf files found in data/osm/")
    else:
        print("[PBF] Detected PBF files:")
        for f in files:
            print("   →", f.name)
    return files


def region_name_from_filename(path: Path) -> str:
    """
    Extract a normalized region name from filename, e.g.:
        europe-latest.osm.pbf        -> "europe"
        north-america-251117.osm.pbf -> "north"
        asia-251117.osm.pbf          -> "asia"
        planet.osm.pbf               -> "planet"
    """
    name = path.name
    if name.endswith(".osm.pbf"):
        name = name[:-8]
    # grab first meaningful chunk
    name = name.split("-", 1)[0]
    name = re.sub(r"[^A-Za-z0-9_]+", "_", name).strip("_")
    return name.lower() or "region"


# ---------------------------------------------------------------------
# MULTI-LAYER HANDLER (SINGLE PASS PER FILE)
# ---------------------------------------------------------------------

class MultiLayerHandler(osmium.SimpleHandler):
    """
    Streams objects from one PBF and, in a single pass:
      - writes industrial features to industrial_out
      - writes military features to military_out

    Nodes:
        - counted
        - progress bar updated
        - filtered and written if tagged as industrial/military

    Ways & Relations:
        - counted
        - progress bar updated
        - filtered and written if tagged as industrial/military
    """

    def __init__(self, industrial_out, military_out, pbar: tqdm, counter: dict):
        super().__init__()
        self.industrial_out = industrial_out
        self.military_out = military_out
        self.pbar = pbar
        self.geojson_factory = GeoJSONFactory()

        self.counter = counter
        self.counter.setdefault("total_processed", 0)
        self.counter.setdefault("industrial_written", 0)
        self.counter.setdefault("military_written", 0)

    # ------------------ Tag-based classifiers ------------------

    def _is_industrial(self, tags) -> bool:
        if not tags:
            return False

        landuse = tags.get("landuse")
        industrial = tags.get("industrial")
        building = tags.get("building")
        man_made = tags.get("man_made")
        power = tags.get("power")

        # Classic OSM industrial tagging
        if landuse == "industrial":
            return True
        if industrial:  # any industrial=*
            return True

        # Factories / plants / works
        if man_made in {"works", "factory"}:
            return True
        if building in {"industrial", "warehouse", "factory", "plant"}:
            return True

        # Power plants are typically industrial installations
        if power == "plant":
            return True

        return False

    def _is_military(self, tags) -> bool:
        if not tags:
            return False

        landuse = tags.get("landuse")
        military = tags.get("military")
        amenity = tags.get("amenity")
        building = tags.get("building")
        boundary = tags.get("boundary")

        # Classic OSM military tagging
        if landuse == "military":
            return True
        if amenity == "military":
            return True
        if military:  # any military=*
            return True

        # Military boundaries
        if boundary == "military":
            return True

        # Common military-ish buildings
        if building in {"barracks", "military"}:
            return True

        return False

    # ------------------ Geometry + writing ------------------

    def _write_feature(self, obj, tags, layer: str):
        try:
            geom = json.loads(self.geojson_factory.create(obj))
        except Exception:
            # Geometry can fail for broken objects; just skip.
            return

        props = {k: v for k, v in tags}
        props["osmid"] = int(obj.id)
        props["osm_type"] = obj.__class__.__name__.lower()
        props["layer"] = layer

        feature = {
            "type": "Feature",
            "geometry": geom,
            "properties": props,
        }

        if layer == "industrial":
            json.dump(feature, self.industrial_out)
            self.industrial_out.write("\n")
            self.counter["industrial_written"] += 1
        else:
            json.dump(feature, self.military_out)
            self.military_out.write("\n")
            self.counter["military_written"] += 1

    # ------------------ OSM object handlers ------------------

    def node(self, n):
        self.counter["total_processed"] += 1
        self.pbar.update(1)

        tags = n.tags
        if self._is_industrial(tags):
            self._write_feature(n, tags, "industrial")
        if self._is_military(tags):
            self._write_feature(n, tags, "military")

    def way(self, w):
        self.counter["total_processed"] += 1
        self.pbar.update(1)

        tags = w.tags
        if self._is_industrial(tags):
            self._write_feature(w, tags, "industrial")
        if self._is_military(tags):
            self._write_feature(w, tags, "military")

    def relation(self, r):
        self.counter["total_processed"] += 1
        self.pbar.update(1)

        tags = r.tags
        if self._is_industrial(tags):
            self._write_feature(r, tags, "industrial")
        if self._is_military(tags):
            self._write_feature(r, tags, "military")


# ---------------------------------------------------------------------
# ESTIMATION
# ---------------------------------------------------------------------

def estimate_total_entities(pbf_path: Path) -> tuple[float, int]:
    """
    Estimate total entities based on file size and current calibration.
    Returns (size_mb, estimated_entities).
    """
    size_mb = pbf_path.stat().st_size / (1024 * 1024)
    est = max(1, int(size_mb * APPROX_ENTITIES_PER_MB))
    return size_mb, est


# ---------------------------------------------------------------------
# INDEX MODE SELECTION
# ---------------------------------------------------------------------

def choose_index_for_file(pbf_path: Path, index_mode: str) -> str:
    """
    Decide which osmium node location index to use for this file.

    index_mode:
        "flex_mem"         -> always use flex_mem
        "sparse_mem_array" -> always use sparse_mem_array
        "auto"             -> choose based on file size

    For "auto" on a large-memory host (≈128 GB):

        - if file < HUGE_PBF_THRESHOLD_MB:
              use "flex_mem" (fast, more RAM)
        - else:
              use "sparse_mem_array" (safer on RAM for huge extracts)
    """
    size_mb = pbf_path.stat().st_size / (1024 * 1024)

    if index_mode == "flex_mem":
        idx = "flex_mem"
    elif index_mode == "sparse_mem_array":
        idx = "sparse_mem_array"
    else:  # auto
        if size_mb >= HUGE_PBF_THRESHOLD_MB:
            idx = "sparse_mem_array"
        else:
            idx = "flex_mem"

    print(f"[Index] {pbf_path.name}: size={size_mb:.1f} MB -> idx='{idx}' (mode={index_mode})")
    return idx


# ---------------------------------------------------------------------
# PER-FILE WORKER (RUNS IN A THREAD OR MAIN THREAD)
# ---------------------------------------------------------------------

def process_single_pbf(pbf_path: Path, idx: str, show_progress: bool = True) -> tuple[int, float]:
    """
    Process one .osm.pbf file for BOTH layers in a single streaming pass.

    Returns:
        (total_entities_processed, file_size_mb)
    """
    region = region_name_from_filename(pbf_path)
    print(f"\n=== Processing file: {pbf_path.name} (region={region}) ===")

    OUT_INDUSTRIAL_DIR.mkdir(parents=True, exist_ok=True)
    OUT_MILITARY_DIR.mkdir(parents=True, exist_ok=True)

    out_industrial = OUT_INDUSTRIAL_DIR / f"{region}_industrial.ndjson"
    out_military = OUT_MILITARY_DIR / f"{region}_military.ndjson"

    print("Input :", pbf_path)
    print("Output (industrial):", out_industrial)
    print("Output (military)  :", out_military)

    size_mb, est_total = estimate_total_entities(pbf_path)
    print(
        f"File size: {size_mb:.1f} MB → est. {est_total:,} objects "
        f"(using approx_entities_per_mb={APPROX_ENTITIES_PER_MB}, idx='{idx}')"
    )

    counter = {}

    with out_industrial.open("w", encoding="utf-8") as f_ind, \
         out_military.open("w", encoding="utf-8") as f_mil:

        pbar = tqdm(
            total=est_total,
            desc=f"{region} all",
            unit="obj",
            leave=False,
            disable=not show_progress,
        )
        handler = MultiLayerHandler(f_ind, f_mil, pbar, counter)
        handler.apply_file(str(pbf_path), locations=True, idx=idx)
        pbar.close()

    real_total = counter.get("total_processed", 0)
    suggested = int(real_total / size_mb) if size_mb > 0 else APPROX_ENTITIES_PER_MB

    print(f"[{region}] Real entities processed (incl. nodes): {real_total:,}")
    print(f"[{region}] Suggested approx_entities_per_mb (this file) = {suggested}")
    print(f"[{region}] Industrial features written: {counter.get('industrial_written', 0):,}")
    print(f"[{region}] Military features written   : {counter.get('military_written', 0):,}")

    return int(real_total), float(size_mb)


# ---------------------------------------------------------------------
# MAIN (HYBRID: PARALLEL FOR SMALL/MEDIUM, SEQUENTIAL FOR HUGE)
# ---------------------------------------------------------------------

def main(max_workers: int | None = None, index_mode: str = "auto", show_progress: bool = True):
    """
    max_workers:
        - None  -> auto (up to 4, or #small_files)
        - >0    -> explicit override

    index_mode:
        - "auto", "flex_mem", or "sparse_mem_array"
    """
    OUT_INDUSTRIAL_DIR.mkdir(parents=True, exist_ok=True)
    OUT_MILITARY_DIR.mkdir(parents=True, exist_ok=True)

    pbf_files = find_pbf_files()
    if not pbf_files:
        return

    # Split into "huge" and "small/medium" by size.
    small_medium_files = []
    huge_files = []

    for p in pbf_files:
        size_mb = p.stat().st_size / (1024 * 1024)
        if size_mb >= HUGE_PBF_THRESHOLD_MB:
            huge_files.append(p)
        else:
            small_medium_files.append(p)

    if small_medium_files:
        print("\n[Scheduling] Small/medium PBFs (parallel):")
        for f in small_medium_files:
            print("   •", f.name)
    if huge_files:
        print("\n[Scheduling] Huge PBFs (sequential):")
        for f in huge_files:
            print("   •", f.name)
    print()

    global_entities = 0.0
    global_mb = 0.0

    # 1) Process small/medium files in parallel.
    if small_medium_files:
        cpu_count = os.cpu_count() or 4
        if max_workers is None:
            # On a 128 GB machine, 3–4 workers is usually safe and fast
            # for continent-sized but not enormous extracts.
            auto_workers = min(4, cpu_count, len(small_medium_files))
            max_workers = auto_workers
        else:
            max_workers = max(1, max_workers)

        print(f"[Threads] Using up to {max_workers} worker(s) for SMALL/MEDIUM PBFs.\n")

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {}
            for pbf in small_medium_files:
                idx = choose_index_for_file(pbf, index_mode)
                fut = executor.submit(process_single_pbf, pbf, idx, show_progress)
                futures[fut] = pbf

            for future in as_completed(futures):
                pbf = futures[future]
                try:
                    entities, mb = future.result()
                    global_entities += entities
                    global_mb += mb
                    print(f"\n[File done] {pbf.name}: entities={entities:,}, size={mb:.1f} MB")
                except KeyboardInterrupt:
                    raise
                except Exception as e:
                    print(f"[ERROR] While processing {pbf.name}: {e}")

    # 2) Process huge files sequentially (one at a time) to avoid RAM spikes.
    if huge_files:
        print("\n[Huge files] Processing sequentially (one at a time for safety).\n")
        for pbf in huge_files:
            idx = choose_index_for_file(pbf, index_mode)
            try:
                entities, mb = process_single_pbf(pbf, idx, show_progress)
                global_entities += entities
                global_mb += mb
                print(f"\n[File done] {pbf.name}: entities={entities:,}, size={mb:.1f} MB")
            except KeyboardInterrupt:
                raise
            except Exception as e:
                print(f"[ERROR] While processing {pbf.name}: {e}")

    # Calibration update
    if global_mb > 0:
        new_value = int(global_entities / global_mb)
        print("\n[Calibration - global]")
        print(f"Total entities processed: {int(global_entities):,}")
        print(f"Total MB: {global_mb:.1f}")
        print(f"New approx_entities_per_mb = {new_value}")
        save_approx_entities_per_mb(new_value)
    else:
        print("\n[Calibration] No data processed; calibration not updated.")


# ---------------------------------------------------------------------
# ENTRY POINT WITH OPTIONAL PROFILING
# ---------------------------------------------------------------------

if __name__ == "__main__":
    import argparse
    import cProfile
    import pstats
    import io

    parser = argparse.ArgumentParser(description="Extract industrial/military layers from OSM PBFs.")
    parser.add_argument(
        "--workers",
        type=int,
        default=None,
        help="Max parallel workers for small/medium PBFs (default: auto, up to 4).",
    )
    parser.add_argument(
        "--index",
        type=str,
        default="auto",
        choices=["auto", "flex_mem", "sparse_mem_array"],
        help="Index mode for osmium node locations (default: auto).",
    )
    parser.add_argument(
        "--no-progress",
        action="store_true",
        help="Disable tqdm progress bars (slightly faster).",
    )
    parser.add_argument(
        "--profile",
        action="store_true",
        help="Enable cProfile (off by default).",
    )
    parser.add_argument(
        "--fast",
        action="store_true",
        help="Shortcut for a fast config: --no-progress --index auto --workers 3.",
    )
    args = parser.parse_args()

    # Apply --fast defaults if requested
    if args.fast:
        if args.workers is None:
            args.workers = 3
        args.no_progress = True
        if args.index == "auto":
            args.index = "auto"  # keep auto; mainly disabling progress here

    show_progress = not args.no_progress

    def run():
        main(max_workers=args.workers, index_mode=args.index, show_progress=show_progress)

    if args.profile:
        prof = cProfile.Profile()
        try:
            prof.enable()
            run()
        except KeyboardInterrupt as e:
            print(f"\n[Profiler] Execution stopped (KeyboardInterrupt: {e})\n")
        except BaseException as e:
            print(f"\n[Profiler] Execution stopped due to error: {e}\n")
        finally:
            prof.disable()
            s = io.StringIO()
            stats = pstats.Stats(prof, stream=s).sort_stats("cumulative")
            stats.print_stats(40)  # top 40 functions by cumulative time
            print(s.getvalue())
            print("[Profiler] Done.")
    else:
        # Normal fast run (no profiling)
        try:
            run()
        except KeyboardInterrupt:
            print("\n[Run] Interrupted by user.\n")

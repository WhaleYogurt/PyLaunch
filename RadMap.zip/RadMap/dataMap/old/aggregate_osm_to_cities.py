#!/usr/bin/env python
"""
aggregate_osm_to_cities.py

Purpose:
    - Load the current master data file: data/processed/data.csv
    - For every OSM industrial/military point (source_layer == 'osm_targets'):
        * Find the nearest city (source_layer == 'cities')
        * Increment per-city counters:
            - osm_industrial_count
            - osm_military_count
    - Remove all OSM rows from the master dataframe.
    - Save a new, aggregated master file as data/processed/data.csv
      (the original is backed up as data/processed/data_with_osm_backup.csv)

Requirements:
    - pandas
    - numpy
    - rtree
    - tqdm
"""

from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm
from rtree import index


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
PROCESSED_DIR = DATA_DIR / "processed"
MASTER_FILE = PROCESSED_DIR / "data.csv"
BACKUP_FILE = PROCESSED_DIR / "data_with_osm_backup.csv"


def build_city_index(cities_df):
    """
    Build an R-tree index over city locations.
    cities_df must have columns: lat, lon
    Returns:
        idx: rtree.index.Index
        city_ids: array of master-dataframe indices for each inserted city
    """
    print(f"[Index] Building R-tree index over {len(cities_df):,} cities...")
    p = index.Property()
    p.dimension = 2
    idx = index.Index(properties=p)

    # We will use a compact 0..N-1 integer ID space for R-tree
    city_ids = np.array(cities_df.index.tolist())  # master df indices

    for i, (master_idx, row) in enumerate(cities_df.iterrows()):
        lat = float(row["lat"])
        lon = float(row["lon"])
        # Insert point as a tiny bounding box
        idx.insert(i, (lon, lat, lon, lat))

    print("[Index] R-tree built.")
    return idx, city_ids


def aggregate_osm_to_cities():
    if not MASTER_FILE.exists():
        raise FileNotFoundError(f"Master data file not found at {MASTER_FILE}")

    print(f"[Master] Loading {MASTER_FILE} (this may take a bit)...")
    df = pd.read_csv(MASTER_FILE, low_memory=False)

    required_cols = ["source_layer", "lat", "lon", "target_class"]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        raise ValueError(f"[Master] data.csv is missing required columns: {missing}")

    # Ensure numeric lat/lon
    df["lat"] = pd.to_numeric(df["lat"], errors="coerce")
    df["lon"] = pd.to_numeric(df["lon"], errors="coerce")

    # Split into cities and OSM
    cities_mask = df["source_layer"] == "cities"
    osm_mask = df["source_layer"] == "osm_targets"

    cities_df = df[cities_mask].dropna(subset=["lat", "lon"]).copy()
    osm_df = df[osm_mask].dropna(subset=["lat", "lon"]).copy()

    # Restrict OSM to industrial/military target classes (if others exist)
    osm_df = osm_df[osm_df["target_class"].isin(["OSM_INDUSTRIAL", "OSM_MILITARY"])].copy()

    print(f"[Info] Cities: {len(cities_df):,}")
    print(f"[Info] OSM industrial/military points: {len(osm_df):,}")

    if len(osm_df) == 0:
        print("[Info] No OSM industrial/military points found; nothing to aggregate.")
        return

    # Initialize per-city counters
    cities_df["osm_industrial_count"] = 0
    cities_df["osm_military_count"] = 0

    idx, city_ids = build_city_index(cities_df)

    # Arrays to store counts in R-tree ID order (0..N-1)
    n_cities = len(cities_df)
    ind_counts = np.zeros(n_cities, dtype=np.int64)
    mil_counts = np.zeros(n_cities, dtype=np.int64)

    # Map from R-tree ID to actual city master index is city_ids[id]
    print("[Aggregate] Assigning each OSM point to nearest city...")
    osm_iter = osm_df.itertuples(index=False)
    for rec in tqdm(osm_iter, total=len(osm_df), desc="Assigning OSM -> cities"):
        lat = float(rec.lat)
        lon = float(rec.lon)
        tclass = getattr(rec, "target_class")

        # R-tree nearest: returns the integer ID we used when inserting
        # (0..n_cities-1), not the original master index
        nearest_id = next(idx.nearest((lon, lat, lon, lat), 1))
        if tclass == "OSM_INDUSTRIAL":
            ind_counts[nearest_id] += 1
        elif tclass == "OSM_MILITARY":
            mil_counts[nearest_id] += 1

    # Write counts back into cities_df (aligned by insertion order)
    # Need a view of cities_df rows in the same order they were inserted.
    # We inserted in .iterrows() order, so we reproduce that order:
    cities_ordered = cities_df.loc[cities_df.index]  # same order as iterrows
    # Confirm order alignment with city_ids:
    assert np.array_equal(city_ids, cities_ordered.index.values)

    cities_df.loc[cities_ordered.index, "osm_industrial_count"] = ind_counts
    cities_df.loc[cities_ordered.index, "osm_military_count"] = mil_counts

    # Push these new columns back into the full master df
    if "osm_industrial_count" not in df.columns:
        df["osm_industrial_count"] = 0
    if "osm_military_count" not in df.columns:
        df["osm_military_count"] = 0

    df.loc[cities_df.index, "osm_industrial_count"] = cities_df["osm_industrial_count"]
    df.loc[cities_df.index, "osm_military_count"] = cities_df["osm_military_count"]

    total_ind = int(ind_counts.sum())
    total_mil = int(mil_counts.sum())
    print(f"[Aggregate] Total OSM industrial assignments: {total_ind:,}")
    print(f"[Aggregate] Total OSM military assignments: {total_mil:,}")

    # Drop all OSM rows from master
    print("[Master] Removing all OSM rows from master dataframe...")
    df_no_osm = df[~osm_mask].copy()
    print(f"[Master] New master row count (no OSM): {len(df_no_osm):,}")

    # Backup original file, then overwrite data.csv
    if not BACKUP_FILE.exists():
        print(f"[Backup] Renaming original data.csv -> {BACKUP_FILE.name}")
        MASTER_FILE.rename(BACKUP_FILE)
    else:
        print(f"[Backup] {BACKUP_FILE.name} already exists; leaving original data.csv as-is.")

    print(f"[Write] Writing new aggregated master to {MASTER_FILE} ...")
    df_no_osm.to_csv(MASTER_FILE, index=False)
    print("[Done] Aggregation complete. data.csv now has city-level OSM counts and no OSM rows.")


if __name__ == "__main__":
    aggregate_osm_to_cities()

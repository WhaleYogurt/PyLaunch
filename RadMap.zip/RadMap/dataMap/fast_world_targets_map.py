#!/usr/bin/env python
"""
fast_world_targets_map.py (city-aggregated OSM version)

Strategic targets map using a unified master database:

- data/processed/data.csv  (built by build_master_data.py, then
  processed by aggregate_osm_to_cities.py)

This master file now contains:
    - cities (with osm_industrial_count, osm_military_count)
    - nuclear_power_plants
    - gppd_large_plants
    - ports
    - airports
    - capitals
    - military_master
    - unesco_sites

and NO rows with source_layer == 'osm_targets'.

Plus:

- data/world_countries.geojson
- data/master_allegiances.csv

Output:
    map.html
"""

from pathlib import Path
import math
import json

import pandas as pd
import folium
from folium.plugins import HeatMap  # used for city-level industrial / military heatmaps

# -------------------------------------------------------------------
# PATHS
# -------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
PROCESSED_DIR = DATA_DIR / "processed"

MASTER_DATA_CSV = PROCESSED_DIR / "data.csv"

WORLD_COUNTRIES_GEOJSON = DATA_DIR / "world_countries.geojson"
ALLEGIANCES_CSV = DATA_DIR / "master_allegiances.csv"

OUTPUT_HTML = "map.html"

# -------------------------------------------------------------------
# CITY TIERS (POPULATION-BASED PRIORITY)
# -------------------------------------------------------------------

TIER1_MIN = 8_000_000    # Top mega-cities
TIER2_MIN = 3_000_000    # Major metros
TIER3_MIN = 500_000      # Likely targets

MARKER_SIZES = {
    "tier1": 9,
    "tier2": 7,
    "tier3": 5,
    "tier4": 4,
}

MARKER_COLORS = {
    "tier1": "red",
    "tier2": "orange",
    "tier3": "gold",
    "tier4": "green",
}

# -------------------------------------------------------------------
# ALLIANCE / BLOC LOGIC
# -------------------------------------------------------------------

BLOC_COLORS = {
    "NATO": "blue",
    "RUSSIAN_BLOC": "red",
    "US_ALLIED_NON_NATO": "teal",
    "OTHER": "gray",
}

NATO_COUNTRIES = {
    "Albania", "Belgium", "Bulgaria", "Canada", "Croatia", "Czech Republic",
    "Czechia", "Denmark", "Estonia", "Finland", "France", "Germany", "Greece",
    "Hungary", "Iceland", "Italy", "Latvia", "Lithuania", "Luxembourg",
    "Montenegro", "Netherlands", "The Netherlands", "North Macedonia",
    "Norway", "Poland", "Portugal", "Romania", "Slovakia", "Slovenia",
    "Spain", "Sweden", "Turkey", "Türkiye", "United Kingdom", "United States",
    "USA", "UK",
}

RUSSIAN_BLOC_COUNTRIES = {
    "Russia", "Russian Federation", "Belarus", "Syria", "Belarus'", "Syrian Arab Republic",
}

US_ALLIED_NON_NATO_COUNTRIES = {
    "Japan", "South Korea", "Republic of Korea", "Australia", "New Zealand",
    "Israel", "Saudi Arabia", "Qatar", "Kuwait", "United Arab Emirates",
}


def normalize_country_name(name: str) -> str:
    if not isinstance(name, str):
        return ""
    return name.strip()


def get_country_bloc(country: str) -> str:
    c = normalize_country_name(country)

    if c in NATO_COUNTRIES:
        return "NATO"
    if c in RUSSIAN_BLOC_COUNTRIES:
        return "RUSSIAN_BLOC"
    if c in US_ALLIED_NON_NATO_COUNTRIES:
        return "US_ALLIED_NON_NATO"

    lower = c.lower()
    if "united states" in lower or lower == "u.s.":
        return "NATO"
    if "united kingdom" in lower or "great britain" in lower:
        return "NATO"
    if "russia" in lower:
        return "RUSSIAN_BLOC"
    if "belarus" in lower:
        return "RUSSIAN_BLOC"

    return "OTHER"


# -------------------------------------------------------------------
# ALIGNMENT / SCORING (TRI-POLAR US/RU/CN)
# -------------------------------------------------------------------

def load_allegiances_scored():
    """
    Load master_allegiances.csv with fields like:
    iso,country,bloc_primary,bloc_detail,color,score_us,score_ru,score_cn,primary_sphere,allegiance_index,tilt
    """
    if not ALLEGIANCES_CSV.exists():
        print(f"[Allegiances] File not found: {ALLEGIANCES_CSV}. Alignment overlays will be skipped.")
        return None

    print(f"[Allegiances] Loading {ALLEGIANCES_CSV}")
    df = pd.read_csv(ALLEGIANCES_CSV, dtype=str)

    required = ["iso", "country", "score_us", "score_ru", "score_cn"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"[Allegiances] CSV missing columns: {missing}")

    df["iso"] = df["iso"].astype(str).str.upper().str.strip()
    df["country"] = df["country"].astype(str).str.strip()

    for col in ["score_us", "score_ru", "score_cn"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(int)

    if "bloc_primary" not in df.columns:
        df["bloc_primary"] = "NON_ALIGNED"
    if "bloc_detail" not in df.columns:
        df["bloc_detail"] = "NON_ALIGNED"
    if "tilt" not in df.columns:
        df["tilt"] = ""

    print(f"[Allegiances] Loaded {len(df)} rows with alignment scores.")
    return df


def add_alignment_layers(world_map, alleg_df):
    """
    Add three polygon overlays:
      - US alignment
      - Russia alignment
      - China alignment
    """
    if alleg_df is None:
        print("[Allegiances] No allegiances data, skipping alignment overlays.")
        return

    if not WORLD_COUNTRIES_GEOJSON.exists():
        print(f"[Allegiances] world_countries.geojson not found at {WORLD_COUNTRIES_GEOJSON}, skipping alignment overlays.")
        return

    print(f"[Allegiances] Loading country polygons from {WORLD_COUNTRIES_GEOJSON}")
    with WORLD_COUNTRIES_GEOJSON.open("r", encoding="utf-8") as f:
        data = json.load(f)

    alleg_df = alleg_df.copy()
    alleg_df["iso2"] = alleg_df["iso"].astype(str).str.upper().str.strip()
    iso_lookup = alleg_df.set_index("iso2").to_dict(orient="index")

    def get_iso_from_props(props):
        for key in ["iso_a2", "ISO_A2", "ISO2", "iso2", "ISO", "iso", "COUNTRY_CODE", "country_code"]:
            if key in props and props[key]:
                return str(props[key]).upper()
        return None

    def get_name_from_props(props):
        for key in ["ADMIN", "admin", "NAME", "name", "NAME_EN", "name_en", "Country", "country"]:
            if key in props and props[key]:
                return str(props[key])
        return "Unknown"

    # Enrich GeoJSON features
    for feat in data.get("features", []):
        props = feat.setdefault("properties", {})
        iso2 = get_iso_from_props(props)
        row = iso_lookup.get(iso2)

        if row is not None:
            su = row.get("score_us", 0)
            sr = row.get("score_ru", 0)
            sc = row.get("score_cn", 0)
            bloc_prim = row.get("bloc_primary", "NON_ALIGNED")
            bloc_detail = row.get("bloc_detail", "NON_ALIGNED")
            tilt = row.get("tilt", "")
            name = row.get("country", get_name_from_props(props))

            label_lines = [
                f"<b>{name}</b> ({iso2})",
                f"Bloc: {bloc_prim} / {bloc_detail}",
                f"US alignment score: {su}",
                f"Russia alignment score: {sr}",
                f"China alignment score: {sc}",
            ]
            if tilt:
                label_lines.append(f"Tilt: {tilt}")

            props["alignment_label"] = "<br>".join(label_lines)
            props["align_score_us"] = int(su)
            props["align_score_ru"] = int(sr)
            props["align_score_cn"] = int(sc)
        else:
            name = get_name_from_props(props)
            props["alignment_label"] = f"<b>{name}</b><br>No alignment data"
            props["align_score_us"] = 0
            props["align_score_ru"] = 0
            props["align_score_cn"] = 0

    def make_style_function(score_key, base_hex):
        def style_fn(feature):
            props = feature.get("properties", {})
            score = int(props.get(score_key, 0) or 0)

            if score <= 0:
                return {
                    "fillColor": "#f0f0f0",
                    "color": "#999999",
                    "weight": 0.5,
                    "fillOpacity": 0.1,
                }

            opacity = 0.15 + 0.13 * min(max(score, 1), 5)
            return {
                "fillColor": base_hex,
                "color": "#555555",
                "weight": 1,
                "fillOpacity": opacity,
            }
        return style_fn

    def highlight_function(feature):
        return {
            "weight": 2,
            "color": "#000000",
            "fillOpacity": 0.4,
        }

    us_group = folium.FeatureGroup(name="US alignment", show=True)
    ru_group = folium.FeatureGroup(name="Russia alignment", show=False)
    cn_group = folium.FeatureGroup(name="China alignment", show=False)

    folium.GeoJson(
        data,
        name="US alignment",
        style_function=make_style_function("align_score_us", "#0000ff"),
        highlight_function=highlight_function,
        tooltip=folium.GeoJsonTooltip(
            fields=["alignment_label"],
            aliases=[""],
            labels=False,
            sticky=True,
        ),
    ).add_to(us_group)

    folium.GeoJson(
        data,
        name="Russia alignment",
        style_function=make_style_function("align_score_ru", "#ff0000"),
        highlight_function=highlight_function,
        tooltip=folium.GeoJsonTooltip(
            fields=["alignment_label"],
            aliases=[""],
            labels=False,
            sticky=True,
        ),
    ).add_to(ru_group)

    folium.GeoJson(
        data,
        name="China alignment",
        style_function=make_style_function("align_score_cn", "#ffd700"),
        highlight_function=highlight_function,
        tooltip=folium.GeoJsonTooltip(
            fields=["alignment_label"],
            aliases=[""],
            labels=False,
            sticky=True,
        ),
    ).add_to(cn_group)

    us_group.add_to(world_map)
    ru_group.add_to(world_map)
    cn_group.add_to(world_map)

    print("[Allegiances] Added US, Russia, and China alignment overlay layers.")


# -------------------------------------------------------------------
# MASTER DATA LOADER
# -------------------------------------------------------------------

def load_master_data():
    if not MASTER_DATA_CSV.exists():
        raise FileNotFoundError(f"Master data CSV not found at {MASTER_DATA_CSV}")

    print(f"[Master] Loading master data from {MASTER_DATA_CSV}")
    df = pd.read_csv(MASTER_DATA_CSV, low_memory=False)

    expected_cols = [
        "source_layer", "target_id", "target_class", "name", "country", "iso2",
        "lat", "lon", "subtype", "population", "capacity_mw", "importance",
        "city_tier", "iata", "link", "notes",
        "osm_industrial_count", "osm_military_count",
    ]
    missing = [c for c in expected_cols if c not in df.columns]
    if missing:
        raise ValueError(f"[Master] data.csv missing expected columns: {missing}")

    df["lat"] = pd.to_numeric(df["lat"], errors="coerce")
    df["lon"] = pd.to_numeric(df["lon"], errors="coerce")
    df = df.dropna(subset=["lat", "lon"])

    if "population" in df.columns:
        df["population"] = pd.to_numeric(df["population"], errors="coerce")
    if "capacity_mw" in df.columns:
        df["capacity_mw"] = pd.to_numeric(df["capacity_mw"], errors="coerce")
    if "importance" in df.columns:
        df["importance"] = pd.to_numeric(df["importance"], errors="coerce")

    df["osm_industrial_count"] = pd.to_numeric(df["osm_industrial_count"], errors="coerce").fillna(0).astype(int)
    df["osm_military_count"] = pd.to_numeric(df["osm_military_count"], errors="coerce").fillna(0).astype(int)

    print(f"[Master] Loaded {len(df)} rows total.")
    return df


def ensure_link(row):
    """Return a usable link: prefer 'link' column; fallback to Google Maps."""
    link = str(row.get("link", "") or "").strip()
    lat = row.get("lat", None)
    lon = row.get("lon", None)
    if link:
        return link
    if pd.notna(lat) and pd.notna(lon):
        return f"https://www.google.com/maps?q={lat},{lon}"
    return ""


# -------------------------------------------------------------------
# BUILD MAP
# -------------------------------------------------------------------

def build_map():
    alleg = load_allegiances_scored()
    master = load_master_data()

    # Convenience slices
    cities = master[master["source_layer"] == "cities"].copy()
    nukes = master[master["source_layer"] == "nuclear_power_plants"].copy()
    gppd = master[master["source_layer"] == "gppd_large_plants"].copy()
    ports = master[master["source_layer"] == "ports"].copy()
    airports = master[master["source_layer"] == "airports"].copy()
    capitals = master[master["source_layer"] == "capitals"].copy()
    mil = master[master["source_layer"] == "military_master"].copy()
    unesco = master[master["source_layer"] == "unesco_sites"].copy()

    print("[Map] Creating base map.")

    # Base map with multiple selectable tile layers (light + satellite), using canvas
    world_map = folium.Map(
        location=[20, 0],
        zoom_start=2,
        tiles=None,
        prefer_canvas=True,  # better performance with many CircleMarkers
    )

    # Light / default basemap
    folium.TileLayer(
        "cartodbpositron",
        name="Light (Carto)",
        control=True
    ).add_to(world_map)

    # Satellite basemap (Esri World Imagery)
    folium.TileLayer(
        tiles="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        attr="Tiles © Esri — Source: Esri, Maxar, Earthstar Geographics, and the GIS User Community",
        name="Satellite (Esri)",
        overlay=False,
        control=True,
    ).add_to(world_map)

    # Global subtle red background
    red_bg_group = folium.FeatureGroup(name="Red background", show=True)
    folium.Rectangle(
        bounds=[[-90, -180], [90, 180]],
        color="red",
        weight=0,
        fill=True,
        fill_color="red",
        fill_opacity=0.25,  # Option A: subtle
    ).add_to(red_bg_group)
    red_bg_group.add_to(world_map)

    # Alignment overlays (US / Russia / China) using polygons
    add_alignment_layers(world_map, alleg)

    # ------------------------------------------------------------
    # Cities (tiers) with aggregated OSM counts
    # ------------------------------------------------------------
    tier_groups = {
        "tier1": folium.FeatureGroup(name="Tier 1 – Mega cities (highest priority)", show=True),
        "tier2": folium.FeatureGroup(name="Tier 2 – Major metros", show=False),
        "tier3": folium.FeatureGroup(name="Tier 3 – ≥ 500k (likely targets)", show=False),
        "tier4": folium.FeatureGroup(name="Tier 4 – < 500k (lower priority)", show=False),
    }

    print("[Map] Adding city markers (with aggregated OSM counts).")
    for _, row in cities.iterrows():
        city = str(row.get("name", "Unknown"))
        country = str(row.get("country", "Unknown"))
        lat = float(row["lat"])
        lon = float(row["lon"])
        pop = row.get("population", None)
        tier = str(row.get("city_tier", "") or "tier4").lower()
        radius = MARKER_SIZES.get(tier, 4)
        color = MARKER_COLORS.get(tier, "green")
        bloc = get_country_bloc(country)
        link = ensure_link(row)

        try:
            pop_str = f"{int(pop):,}" if pd.notna(pop) else "Unknown"
        except Exception:
            pop_str = "Unknown"

        ind_count = int(row.get("osm_industrial_count", 0) or 0)
        mil_count = int(row.get("osm_military_count", 0) or 0)

        osm_summary = (
            f"OSM industrial sites snapped to this city: {ind_count:,}<br>"
            f"OSM military sites snapped to this city: {mil_count:,}<br>"
        )

        maps_link_html = f'<a href="{link}" target="_blank">View in Google Maps</a>' if link else ""

        popup_html = f"""
        <b>{city}, {country}</b><br>
        Pre-war population: {pop_str}<br>
        Tier: {tier.upper()} (population priority)<br>
        Bloc (simple city-level): {bloc}<br>
        {osm_summary}
        {maps_link_html}
        """

        m = folium.CircleMarker(
            location=[lat, lon],
            radius=radius,
            popup=folium.Popup(popup_html, max_width=280),
            color=color,
            fill=True,
            fill_color=color,
            fill_opacity=0.8,
        )
        tier_groups.setdefault(tier, tier_groups["tier4"]).add_child(m)

    for g in tier_groups.values():
        g.add_to(world_map)

    # ------------------------------------------------------------
    # City OSM density heatmaps – industrial and military, separate
    # Negative-style: blue-on-red, with blue gradient
    # ------------------------------------------------------------
    if len(cities) > 0:
        print("[Map] Adding industrial and military city OSM density heatmaps.")

        # Industrial heatmap
        ind_group = folium.FeatureGroup(name="Industrial OSM density (by city)", show=False)
        ind_points = []
        for _, row in cities.iterrows():
            lat = float(row["lat"])
            lon = float(row["lon"])
            if math.isnan(lat) or math.isnan(lon):
                continue

            ind_count = int(row.get("osm_industrial_count", 0) or 0)
            # Baseline weight so zero-count cities still appear as dark blue
            if ind_count <= 0:
                weight = 0.1
            else:
                weight = 1.0 + math.log10(ind_count + 1.0)
            ind_points.append([lat, lon, weight])

        if ind_points:
            HeatMap(
                ind_points,
                radius=10,
                blur=15,
                max_zoom=5,
                min_opacity=0.25,
                gradient={
                    0.0: "darkblue",
                    0.3: "blue",
                    0.7: "cyan",
                    1.0: "white",
                },
            ).add_to(ind_group)
            ind_group.add_to(world_map)

        # Military heatmap
        mil_group_heat = folium.FeatureGroup(name="Military OSM density (by city)", show=False)
        mil_points = []
        for _, row in cities.iterrows():
            lat = float(row["lat"])
            lon = float(row["lon"])
            if math.isnan(lat) or math.isnan(lon):
                continue

            mil_count = int(row.get("osm_military_count", 0) or 0)
            if mil_count <= 0:
                weight = 0.1
            else:
                weight = 1.0 + math.log10(mil_count + 1.0)
            mil_points.append([lat, lon, weight])

        if mil_points:
            HeatMap(
                mil_points,
                radius=10,
                blur=15,
                max_zoom=5,
                min_opacity=0.25,
                gradient={
                    0.0: "darkblue",
                    0.3: "blue",
                    0.7: "cyan",
                    1.0: "white",
                },
            ).add_to(mil_group_heat)
            mil_group_heat.add_to(world_map)

    # ------------------------------------------------------------
    # Capitals
    # ------------------------------------------------------------
    if len(capitals) > 0:
        print("[Map] Adding bloc-colored capitals layer (allegiance).")
        cap_group = folium.FeatureGroup(name="Country bloc (capitals by bloc)", show=False)

        for _, row in capitals.iterrows():
            city = str(row.get("name", "Unknown"))
            country = str(row.get("country", "Unknown"))
            lat = float(row["lat"])
            lon = float(row["lon"])
            bloc = get_country_bloc(country)
            color = BLOC_COLORS.get(bloc, "gray")
            link = ensure_link(row)
            maps_link_html = f'<a href="{link}" target="_blank">View in Google Maps</a>' if link else ""

            popup_html = f"""
            <b>{city}, {country}</b><br>
            National capital<br>
            Bloc (simple): {bloc}<br>
            {maps_link_html}
            """

            folium.CircleMarker(
                location=[lat, lon],
                radius=5,
                popup=folium.Popup(popup_html, max_width=220),
                color=color,
                fill=False,
                weight=3,
            ).add_to(cap_group)

        cap_group.add_to(world_map)

    # ------------------------------------------------------------
    # Nuclear power plants
    # ------------------------------------------------------------
    if len(nukes) > 0:
        print("[Map] Adding nuclear plants layer (from master).")
        nuke_group = folium.FeatureGroup(name="Nuclear power plants", show=True)

        for _, row in nukes.iterrows():
            lat = float(row["lat"])
            lon = float(row["lon"])
            if math.isnan(lat) or math.isnan(lon):
                continue

            name = str(row.get("name", "Unknown"))
            country = str(row.get("country", "Unknown"))
            cap = row.get("capacity_mw", None)
            try:
                cap_mw = float(cap) if pd.notna(cap) else None
            except Exception:
                cap_mw = None
            cap_str = f"{cap_mw:,.0f} MW" if cap_mw is not None else "Unknown"

            reactor_type = str(row.get("subtype", ""))
            notes = str(row.get("notes", ""))
            status_text = ""
            if notes.lower().startswith("status:"):
                status_text = notes

            if cap_mw is None:
                radius = 7
            elif cap_mw >= 2000:
                radius = 11
            elif cap_mw >= 1000:
                radius = 9
            elif cap_mw >= 500:
                radius = 7
            else:
                radius = 5

            link = ensure_link(row)
            maps_link_html = f'<a href="{link}" target="_blank">View in Google Maps</a>' if link else ""

            popup_html = f"""
            <b>{name}</b><br>
            Country: {country}<br>
            Status: {status_text}<br>
            Reactor type: {reactor_type}<br>
            Capacity: {cap_str}<br>
            {maps_link_html}
            """

            folium.CircleMarker(
                location=[lat, lon],
                radius=radius,
                popup=folium.Popup(popup_html, max_width=260),
                color="purple",
                fill=True,
                fill_color="purple",
                fill_opacity=0.7,
            ).add_to(nuke_group)

        nuke_group.add_to(world_map)

    # ------------------------------------------------------------
    # Large conventional power plants (GPPD)
    # ------------------------------------------------------------
    if len(gppd) > 0:
        print("[Map] Adding large conventional power plants layer (from master).")
        pp_group = folium.FeatureGroup(name="Large non-nuclear power plants (≥ 500 MW)", show=False)
        for _, row in gppd.iterrows():
            lat = float(row["lat"])
            lon = float(row["lon"])
            if math.isnan(lat) or math.isnan(lon):
                continue

            name = str(row.get("name", "Unknown"))
            country = str(row.get("country", "Unknown"))
            fuel = str(row.get("subtype", "Unknown"))
            cap = row.get("capacity_mw", None)

            if pd.isna(cap):
                cap_mw = 0.0
            else:
                cap_mw = float(cap)

            radius = 4 + min(8, math.log10(max(1.0, cap_mw)) * 2.0)

            link = ensure_link(row)
            maps_link_html = f'<a href="{link}" target="_blank">View in Google Maps</a>' if link else ""

            popup_html = f"""
            <b>{name}</b><br>
            Country: {country}<br>
            Fuel: {fuel}<br>
            Capacity: {cap_mw:,.0f} MW<br>
            {maps_link_html}
            """

            folium.CircleMarker(
                location=[lat, lon],
                radius=radius,
                popup=folium.Popup(popup_html, max_width=260),
                color="black",
                fill=True,
                fill_color="black",
                fill_opacity=0.6,
            ).add_to(pp_group)
        pp_group.add_to(world_map)

    # ------------------------------------------------------------
    # Ports
    # ------------------------------------------------------------
    if len(ports) > 0:
        print("[Map] Adding ports layer (from master).")
        port_group = folium.FeatureGroup(name="Major ports", show=False)
        for _, row in ports.iterrows():
            lat = float(row["lat"])
            lon = float(row["lon"])
            if math.isnan(lat) or math.isnan(lon):
                continue

            name = str(row.get("name", "Unknown"))
            iso2 = str(row.get("iso2", ""))

            link = ensure_link(row)
            maps_link_html = f'<a href="{link}" target="_blank">View in Google Maps</a>' if link else ""

            popup_html = f"""
            <b>{name}</b><br>
            Country code: {iso2}<br>
            Strategic value: Sea logistics / naval access<br>
            {maps_link_html}
            """

            folium.CircleMarker(
                location=[lat, lon],
                radius=4,
                popup=folium.Popup(popup_html, max_width=260),
                color="darkblue",
                fill=True,
                fill_color="darkblue",
                fill_opacity=0.7,
            ).add_to(port_group)
        port_group.add_to(world_map)

    # ------------------------------------------------------------
    # Airports
    # ------------------------------------------------------------
    if len(airports) > 0:
        print("[Map] Adding airports layer (from master).")
        air_group = folium.FeatureGroup(name="Major airports (IATA)", show=False)
        for _, row in airports.iterrows():
            lat = float(row["lat"])
            lon = float(row["lon"])
            if math.isnan(lat) or math.isnan(lon):
                continue

            name = str(row.get("name", "Unknown"))
            country = str(row.get("country", "Unknown"))
            iata = str(row.get("iata", ""))

            link = ensure_link(row)
            maps_link_html = f'<a href="{link}" target="_blank">View in Google Maps</a>' if link else ""

            popup_html = f"""
            <b>{name}</b><br>
            Country: {country}<br>
            IATA: {iata}<br>
            Strategic value: Airlift / logistics / bomber base potential<br>
            {maps_link_html}
            """

            folium.CircleMarker(
                location=[lat, lon],
                radius=4,
                popup=folium.Popup(popup_html, max_width=260),
                color="darkred",
                fill=True,
                fill_color="darkred",
                fill_opacity=0.7,
            ).add_to(air_group)
        air_group.add_to(world_map)

    # ------------------------------------------------------------
    # Military bases (curated)
    # ------------------------------------------------------------
    if len(mil) > 0:
        print("[Map] Adding strategic military bases layer (from master).")

        mil_group = folium.FeatureGroup(name="Strategic military bases (military_master.csv)", show=True)

        for _, row in mil.iterrows():
            lat = float(row["lat"])
            lon = float(row["lon"])
            if math.isnan(lat) or math.isnan(lon):
                continue

            name = str(row.get("name", "Unknown"))
            country = str(row.get("country", "Unknown"))

            importance = row.get("importance", 3)
            try:
                importance = int(importance) if pd.notna(importance) else 3
            except Exception:
                importance = 3

            notes = str(row.get("notes", ""))

            bloc = "OTHER"
            if "Bloc:" in notes:
                try:
                    after = notes.split("Bloc:", 1)[1]
                    bloc_raw = after.split(";", 1)[0].strip()
                    if bloc_raw:
                        bloc = bloc_raw
                except Exception:
                    pass

            color = BLOC_COLORS.get(bloc, "gray")
            radius = 4 + max(0, min(importance, 6))

            link = ensure_link(row)
            maps_link_html = f'<a href="{link}" target="_blank">View in Google Maps</a>' if link else ""

            popup_html = f"""
            <b>{name}</b><br>
            Country: {country}<br>
            Bloc: {bloc}<br>
            Importance: {importance}/5<br>
            <i>{notes}</i><br>
            {maps_link_html}
            """

            folium.CircleMarker(
                location=[lat, lon],
                radius=radius,
                popup=folium.Popup(popup_html, max_width=320),
                color=color,
                fill=True,
                fill_color=color,
                fill_opacity=0.85,
                weight=2,
            ).add_to(mil_group)

        mil_group.add_to(world_map)

    # ------------------------------------------------------------
    # UNESCO World Heritage Sites
    # ------------------------------------------------------------
    if len(unesco) > 0:
        print("[Map] Adding UNESCO World Heritage Sites layer (from master).")
        unesco_group = folium.FeatureGroup(name="UNESCO World Heritage Sites", show=False)

        cat_colors = {
            "Cultural": "purple",
            "Natural": "green",
            "Mixed": "darkblue",
        }

        for _, row in unesco.iterrows():
            lat = float(row["lat"])
            lon = float(row["lon"])
            if math.isnan(lat) or math.isnan(lon):
                continue

            name = str(row.get("name", "Unknown"))
            category = str(row.get("subtype", "Unknown"))  # subtype holds category
            desc = str(row.get("notes", ""))  # truncated description
            unesco_link = str(row.get("link", ""))  # UNESCO listing

            color = cat_colors.get(category, "gray")

            maps_link_html = f'<a href="https://www.google.com/maps?q={lat},{lon}" target="_blank">View in Google Maps</a>'
            unesco_link_html = f'<a href="{unesco_link}" target="_blank">UNESCO listing</a>' if unesco_link else ""

            popup_html = f"""
            <b>{name}</b><br>
            Category: {category}<br>
            {unesco_link_html}<br>
            {maps_link_html}<br>
            <hr>
            <small>{desc[:500]}{"..." if len(desc) > 500 else ""}</small>
            """

            folium.CircleMarker(
                location=[lat, lon],
                radius=4,
                popup=folium.Popup(popup_html, max_width=320),
                color=color,
                fill=True,
                fill_color=color,
                fill_opacity=0.8,
                weight=1.5,
            ).add_to(unesco_group)

        unesco_group.add_to(world_map)

    # ------------------------------------------------------------
    # Layer control + legend + alignment toggle JS
    # ------------------------------------------------------------
    folium.LayerControl(collapsed=False).add_to(world_map)

    legend_html = f"""
    <div style="
        position: fixed;
        bottom: 20px;
        left: 20px;
        width: 380px;
        background-color: white;
        border: 2px solid grey;
        z-index: 9999;
        font-size: 12px;
        padding: 8px;
    ">
    <b>Background</b><br>
    <span style='color:red'>&#9632;</span> Red background layer (toggleable)<br>
    <hr>
    <b>Strategic City Tiers (population-based)</b><br>
    <span style='color:red'>&#9679;</span> Tier 1: &ge; {TIER1_MIN:,}<br>
    <span style='color:orange'>&#9679;</span> Tier 2: {TIER2_MIN:,}–{TIER1_MIN-1:,}<br>
    <span style='color:gold'>&#9679;</span> Tier 3: {TIER3_MIN:,}–{TIER2_MIN-1:,}<br>
    <span style='color:green'>&#9679;</span> Tier 4: &lt; {TIER3_MIN:,}<br>
    <hr>
    <b>OSM density snapped to cities</b><br>
    - City marker popup shows industrial + military OSM counts.<br>
    - "Industrial OSM density (by city)" heatmap (blue/cyan/white).<br>
    - "Military OSM density (by city)" heatmap (blue/cyan/white).<br>
    Blue dots on red = easy visual contrast.<br>
    <hr>
    <b>Country alignment overlays</b><br>
    <small>Use the layer control to view one bloc at a time.</small><br>
    <span style='color:blue'>&#9632;</span> US alignment<br>
    <span style='color:red'>&#9632;</span> Russia alignment<br>
    <span style='color:gold'>&#9632;</span> China alignment<br>
    <small>Score per bloc: -5 = hostile, 0 = neutral, +5 = strongly aligned.<br>
    Darker fill = stronger positive alignment to that bloc.<br>
    Grey = neutral/negative for that bloc.</small><br>
    <hr>
    <b>Military / political blocs (capitals / bases)</b><br>
    <span style='color:blue'>&#9679;</span> NATO<br>
    <span style='color:teal'>&#9679;</span> US-allied non-NATO<br>
    <span style='color:red'>&#9679;</span> Russian bloc<br>
    <span style='color:gray'>&#9679;</span> Other / unknown<br>
    <hr>
    <b>UNESCO sites</b><br>
    <span style='color:purple'>&#9679;</span> Cultural<br>
    <span style='color:green'>&#9679;</span> Natural<br>
    <span style='color:darkblue'>&#9679;</span> Mixed / other<br>
    </div>
    """
    world_map.get_root().html.add_child(folium.Element(legend_html))

    alignment_js = f"""
    <script>
    var alignmentLayerNames = ['US alignment', 'Russia alignment', 'China alignment'];
    var map = {world_map.get_name()};
    map.on('overlayadd', function(e) {{
        var addedName = e.name || (e.layer && e.layer.options && e.layer.options.name);
        if (alignmentLayerNames.indexOf(addedName) !== -1) {{
            alignmentLayerNames.forEach(function(n) {{
                if (n !== addedName) {{
                    map.eachLayer(function(layer) {{
                        if (layer.options && layer.options.name === n && map.hasLayer(layer)) {{
                            map.removeLayer(layer);
                        }}
                    }});
                }}
            }});
        }}
    }});
    </script>
    """
    world_map.get_root().html.add_child(folium.Element(alignment_js))

    print(f"[Map] Saving to {OUTPUT_HTML}")
    world_map.save(OUTPUT_HTML)
    print("[Map] Done.")


if __name__ == "__main__":
    build_map()

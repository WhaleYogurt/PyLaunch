#!/usr/bin/env python
"""
inject_military_structured_fields.py

Reconstructs structured military fields in dataMap/data/processed/data.csv
from the flattened 'notes' column for rows where source_layer == 'military_master'.

It will:
- Parse strings of the form:
    "Bloc: NATO; Type: NAVAL_BASE; Role: ssbn_base; Notes: French SSBN base near Brest"
- Populate / overwrite columns:
    bloc, type, role, notes   (cleaned)
- Create a backup:
    dataMap/data/processed/data_before_military_parse_backup.csv
"""

import os
import re
import shutil
from typing import Tuple, Optional

import pandas as pd

BASE_DIR = os.path.dirname(__file__)
DATAMAP_DIR = os.path.join(BASE_DIR, "dataMap")
DATA_DIR = os.path.join(DATAMAP_DIR, "data")
PROCESSED_DIR = os.path.join(DATA_DIR, "processed")

MASTER_PATH = os.path.join(PROCESSED_DIR, "data.csv")
BACKUP_PATH = os.path.join(PROCESSED_DIR, "data_before_military_parse_backup.csv")

# Pattern like:
# "Bloc: NATO; Type: NAVAL_BASE; Role: ssbn_base; Notes: French SSBN base near Brest"
NOTES_PATTERN = re.compile(
    r"^\s*Bloc:\s*(?P<bloc>.*?);\s*"
    r"Type:\s*(?P<type>.*?);\s*"
    r"Role:\s*(?P<role>.*?);\s*"
    r"Notes:\s*(?P<notes>.*)\s*$",
    re.IGNORECASE,
)


def _clean_val(v: Optional[str]) -> Optional[str]:
    if v is None:
        return None
    v = str(v).strip()
    if v == "" or v.lower() == "nan":
        return None
    return v


def parse_notes(cell) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    """
    Parse a single notes cell into (bloc, type, role, notes_clean).

    If it doesn't match the pattern, returns (None, None, None, original_text_or_None).
    """
    if not isinstance(cell, str):
        return None, None, None, None

    txt = cell.strip()
    m = NOTES_PATTERN.match(txt)
    if not m:
        return None, None, None, _clean_val(txt)

    bloc = _clean_val(m.group("bloc"))
    type_ = _clean_val(m.group("type"))
    role = _clean_val(m.group("role"))
    notes_clean = _clean_val(m.group("notes"))

    return bloc, type_, role, notes_clean


def main():
    if not os.path.exists(MASTER_PATH):
        raise FileNotFoundError(f"Master data file not found at {MASTER_PATH}")

    print(f"[Paths] Master: {MASTER_PATH}")
    print(f"[Paths] Backup: {BACKUP_PATH}")

    df = pd.read_csv(MASTER_PATH, low_memory=False)
    print(f"[Load] Loaded {len(df):,} rows with {len(df.columns)} columns.")

    if "source_layer" not in df.columns:
        raise RuntimeError("Expected column 'source_layer' not found in master CSV.")

    mil_mask = df["source_layer"] == "military_master"
    num_mil = mil_mask.sum()
    print(f"[Filter] Identified {num_mil:,} military_master rows.")

    if num_mil == 0:
        print("[Info] No military_master rows found; nothing to do.")
        return

    if "notes" not in df.columns:
        raise RuntimeError("Expected column 'notes' not found in master CSV.")

    # Backup original master once
    if not os.path.exists(BACKUP_PATH):
        print(f"[Backup] Creating backup at {BACKUP_PATH}")
        shutil.copy2(MASTER_PATH, BACKUP_PATH)
    else:
        print(f"[Backup] Backup already exists at {BACKUP_PATH}")

    # Ensure destination columns exist
    for col in ["bloc", "type", "role"]:
        if col not in df.columns:
            df[col] = pd.NA

    # Parse notes for military rows only
    print("[Parse] Parsing 'notes' column for military_master rows...")
    parsed = df.loc[mil_mask, "notes"].apply(
        lambda v: pd.Series(parse_notes(v), index=["bloc_new", "type_new", "role_new", "notes_clean"])
    )

    # Fill / overwrite structured columns where we successfully parsed something
    for col in ["bloc", "type", "role"]:
        new_col = f"{col}_new"
        if new_col in parsed.columns:
            mask_nonnull = parsed[new_col].notna()
            updated = mask_nonnull.sum()
            print(f"[Update] Setting {col} from parsed {new_col} on {updated:,} rows.")
            df.loc[mil_mask & mask_nonnull, col] = parsed.loc[mask_nonnull, new_col]

    # Replace notes with cleaned text when available
    mask_notes_nonnull = parsed["notes_clean"].notna()
    updated_notes = mask_notes_nonnull.sum()
    print(f"[Update] Cleaning 'notes' text on {updated_notes:,} rows.")
    df.loc[mil_mask & mask_notes_nonnull, "notes"] = parsed.loc[mask_notes_nonnull, "notes_clean"]

    # Quick sanity sample
    print("[Sample] First 5 updated military rows:")
    sample_cols = ["name", "country", "bloc", "type", "role", "lat", "lon", "importance", "notes", "source_layer"]
    print(df.loc[mil_mask, sample_cols].head(5).to_string(index=False))

    # Save back
    df.to_csv(MASTER_PATH, index=False)
    print(f"[Write] Updated master CSV with structured military fields at {MASTER_PATH}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python
"""
Generate a compact textual report about dataMap/data/processed/data.csv
for debugging the strike scenario & military priority model.

Outputs:
    - Prints a summary to stdout
    - Writes a detailed report to:
        dataMap/data/processed/data_profile_report.txt
"""

import os
from typing import List

import pandas as pd

BASE_DIR = os.path.dirname(__file__)
DATAMAP_DIR = os.path.join(BASE_DIR, "dataMap")
DATA_DIR = os.path.join(DATAMAP_DIR, "data")
PROCESSED_DIR = os.path.join(DATA_DIR, "processed")

MASTER_PATH = os.path.join(PROCESSED_DIR, "data.csv")
REPORT_PATH = os.path.join(PROCESSED_DIR, "data_profile_report.txt")


def add_section(lines: List[str], title: str):
    lines.append("")
    lines.append("=" * 80)
    lines.append(title)
    lines.append("=" * 80)
    lines.append("")


def safe_col_stats(df: pd.DataFrame, col: str) -> List[str]:
    """Return a few basic stats for a column if it exists."""
    out = []
    if col not in df.columns:
        out.append(f"- {col}: MISSING")
        return out

    s = df[col]
    nonnull = s.notna().sum()
    out.append(f"- {col}: present, non-null rows: {nonnull:,} / {len(df):,}")

    # numeric-ish stats for numeric-looking columns
    if pd.api.types.is_numeric_dtype(s):
        desc = s.describe(percentiles=[0.1, 0.5, 0.9])
        out.append(f"  min={desc.get('min', 'n/a')}, max={desc.get('max', 'n/a')}, "
                   f"mean={desc.get('mean', 'n/a')}, "
                   f"p10={desc.get('10%', 'n/a')}, "
                   f"p50={desc.get('50%', 'n/a')}, "
                   f"p90={desc.get('90%', 'n/a')}")
    else:
        # For non-numeric: a few common values
        vc = s.astype(str).value_counts(dropna=True).head(5)
        out.append("  top values:")
        for v, c in vc.items():
            out.append(f"    '{v}': {c:,}")
    return out


def sample_rows_block(df: pd.DataFrame, cols: List[str], n: int = 10) -> List[str]:
    """Return a formatted block of up to n sample rows with selected columns."""
    subset_cols = [c for c in cols if c in df.columns]
    if not subset_cols:
        return ["(no requested columns found in dataframe)"]

    sample = df[subset_cols].head(n)
    # use to_string for a compact but readable table
    return [sample.to_string(index=False)]


def main():
    if not os.path.exists(MASTER_PATH):
        raise FileNotFoundError(f"Master data file not found at {MASTER_PATH}")

    print(f"[Paths] Master:  {MASTER_PATH}")
    print(f"[Paths] Report:  {REPORT_PATH}")

    df = pd.read_csv(MASTER_PATH, low_memory=False)
    print(f"[Master] Loaded {len(df):,} rows with {len(df.columns)} columns.")

    lines: List[str] = []

    # ------------------------------------------------------------------
    # GLOBAL SUMMARY
    # ------------------------------------------------------------------
    add_section(lines, "GLOBAL SUMMARY")

    lines.append(f"Master CSV path: {MASTER_PATH}")
    lines.append(f"Total rows: {len(df):,}")
    lines.append(f"Total columns: {len(df.columns):,}")
    lines.append("")
    lines.append("Columns:")
    for c in df.columns:
        lines.append(f"  - {c}")
    lines.append("")

    if "source_layer" in df.columns:
        lines.append("source_layer value counts (top 20):")
        lines.append(df["source_layer"].fillna("<<NULL>>").value_counts().head(20).to_string())
    else:
        lines.append("WARNING: column 'source_layer' is missing.")
    lines.append("")

    # ------------------------------------------------------------------
    # CITY-LIKE ROWS
    # ------------------------------------------------------------------
    if "source_layer" in df.columns:
        cities = df[df["source_layer"] == "cities"].copy()
    else:
        # fallback: anything with a population
        if "population" in df.columns:
            cities = df[df["population"].notna()].copy()
        else:
            cities = pd.DataFrame([])

    add_section(lines, "CITY-LIKE ROWS (source_layer == 'cities' OR population present)")

    lines.append(f"City-like rows: {len(cities):,}")
    if not cities.empty:
        key_city_cols = [
            "name", "city", "country", "iso2",
            "lat", "lon",
            "population",
            "osm_industrial_count", "osm_military_count",
            "is_capital", "city_tier",
            "source_layer",
        ]
        for col in key_city_cols:
            lines.extend(safe_col_stats(cities, col))

        lines.append("")
        lines.append("Sample city-like rows (first 10):")
        lines.extend(sample_rows_block(cities, key_city_cols, n=10))
    else:
        lines.append("No city-like rows found.")

    # ------------------------------------------------------------------
    # MILITARY ROWS
    # ------------------------------------------------------------------
    if "source_layer" in df.columns:
        mil = df[df["source_layer"] == "military_master"].copy()
    else:
        # heuristic fallback
        cols_needed = {"bloc", "type", "importance"}
        has_cols = cols_needed.issubset(df.columns)
        mil = df[df["bloc"].notna() & df["type"].notna() & df["importance"].notna()].copy() if has_cols else pd.DataFrame([])

    add_section(lines, "MILITARY ROWS (source_layer == 'military_master' OR heuristic)")

    lines.append(f"Military rows: {len(mil):,}")
    if not mil.empty:
        key_mil_cols = [
            "name", "country", "iso2",
            "lat", "lon",
            "type", "bloc", "importance",
            "osm_military_count",
            "priority_US", "priority_RU", "priority_CN",
            "is_silo",
            "notes",
            "source_layer",
        ]
        for col in key_mil_cols:
            lines.extend(safe_col_stats(mil, col))

        # type distribution
        if "type" in mil.columns:
            lines.append("")
            lines.append("Military 'type' value counts (top 30):")
            lines.append(mil["type"].astype(str).value_counts(dropna=False).head(30).to_string())
        else:
            lines.append("No 'type' column on military rows.")

        # priority distribution
        for col in ["priority_US", "priority_RU", "priority_CN"]:
            if col in mil.columns:
                lines.append("")
                lines.append(f"{col} value counts:")
                lines.append(mil[col].value_counts(dropna=False).sort_index().to_string())

        # type x priority crosstab (for US) truncated
        if "type" in mil.columns and "priority_US" in mil.columns:
            lines.append("")
            lines.append("Crosstab: type x priority_US (top 40 rows):")
            ct = pd.crosstab(mil["type"].astype(str), mil["priority_US"]).sort_index()
            # limit size
            lines.append(ct.head(40).to_string())

        lines.append("")
        lines.append("Sample military rows (first 15):")
        lines.extend(sample_rows_block(mil, key_mil_cols, n=15))
    else:
        lines.append("No military rows found.")

    # ------------------------------------------------------------------
    # PRIORITY COLUMNS (GLOBAL VIEW)
    # ------------------------------------------------------------------
    add_section(lines, "GLOBAL PRIORITY COLUMN CHECK")

    for col in ["priority_US", "priority_RU", "priority_CN"]:
        lines.extend(safe_col_stats(df, col))

    # ------------------------------------------------------------------
    # SAVE REPORT
    # ------------------------------------------------------------------
    os.makedirs(PROCESSED_DIR, exist_ok=True)
    with open(REPORT_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"[Report] Wrote report to {REPORT_PATH}")
    print("[Done] You can now copy-paste that file into ChatGPT for further analysis.")


if __name__ == "__main__":
    main()

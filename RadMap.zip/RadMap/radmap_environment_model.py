#!/usr/bin/env python
"""
radmap_environment_model.py

Offline environment model for RadMap (Option A, minute time slices).

Takes the strike scenario and master data and produces a per-minute
global timeline of:

- Remaining population
- Cumulative deaths (blast/thermal, radiation, grid collapse)
- Grid uptime fraction
- Global radiation index (0–1)
- Per-strike radiation cloud strength over time (for mapping)

Inputs (default):
    dataMap/data/processed/strike_scenario_US_RU_GLOBAL.json
    dataMap/data/processed/data.csv

Output:
    dataMap/data/processed/strike_environment_US_RU_GLOBAL_minute.json

You can load this JSON in fast_world_strike_animation_map.py to drive
the UI panel and (later) a dynamic radiation heatmap.
"""

import os
import json
import math
from dataclasses import dataclass, asdict
from typing import List, Dict, Any, Tuple, Optional

# -------------------------------
# Paths
# -------------------------------

BASE_DIR = os.path.dirname(__file__)
DATAMAP_DIR = os.path.join(BASE_DIR, "dataMap")
DATA_DIR = os.path.join(DATAMAP_DIR, "data")
PROCESSED_DIR = os.path.join(DATA_DIR, "processed")

SCENARIO_PATH = os.path.join(PROCESSED_DIR, "strike_scenario_US_RU_GLOBAL.json")
MASTER_DATA_PATH = os.path.join(PROCESSED_DIR, "data.csv")

OUTPUT_ENV_PATH = os.path.join(
    PROCESSED_DIR, "strike_environment_US_RU_GLOBAL_minute.json"
)

# -------------------------------
# Global config
# -------------------------------

DISPLAY_WORLD_POP = 8_000_000_000  # global population used for display/simulation

# Simulation horizon: time after last impact (days)
POSTWAR_DAYS = 60  # "weeks–months" instead of full 1 year to keep data manageable

# Core time step (hours)
SIM_DT_HOURS = 1.0 / 60.0  # 1 minute

# Radiation model: multi-component exponential (early / mid / long)
# half-life in HOURS, rough placeholder profile.
RADIATION_COMPONENTS = [
    {"half_life_hours": 0.5, "weight": 0.55},   # very early fallout (minutes–hours)
    {"half_life_hours": 24.0, "weight": 0.30},  # intermediate (days)
    {"half_life_hours": 24.0 * 30.0, "weight": 0.15},  # long tail (months)
]

# Radiation grid for global scalar index (hourly for efficiency)
RADIATION_SERIES_DT_HOURS = 1.0

# Radiation spatial model for heatmap frames
RADIATION_HEATMAP_DT_HOURS = 1.0  # one frame per hour
RADIATION_SPATIAL_TAU_CUTOFF_HOURS = 72.0  # ignore clouds older than 3 days

# Grid model
GRID_MIN_FRACTION = 0.05           # hard floor (never fully zero)
GRID_PHYSICAL_MAX_DROP = 0.8       # max drop from direct hits (instant damage)
GRID_DYNAMIC_DECAY_RATE = 0.002    # per hour scaling for slow collapse

# Post-war mortality
RAD_POSTWAR_DAILY_MORTALITY_MAX = 0.03     # max daily radiation mortality at rad_index=1
RAD_MORTALITY_EXP = 1.4                    # non-linear scaling with radiation index

GRID_POSTWAR_DAILY_MORTALITY_MAX = 0.02   # max daily grid mortality at full blackout
GRID_MORTALITY_EXP = 1.7                  # non-linear scaling with (1-grid_frac)

# Infrastructure model thresholds
CITY_POP_MIN_FOR_GRID = 5_000_000          # only very large cities affect grid shock
CITY_MAX_DIST_KM = 150.0                   # city influence radius
CITY_DIST_DECAY_KM = 75.0

PLANT_CAP_MIN_FOR_GRID = 500.0             # MW, large plants only
PLANT_MAX_DIST_KM = 200.0
PLANT_DIST_DECAY_KM = 100.0

# -------------------------------
# Data structures
# -------------------------------


@dataclass
class ImpactEvent:
    t: float  # impact time (hours)
    casualties: int  # immediate blast/thermal deaths
    yield_kt: float
    lat: Optional[float]
    lon: Optional[float]
    grid_shock: float = 0.0  # filled later


@dataclass
class TimeState:
    t: float  # hours since scenario start
    remaining: int
    dead_blast: int
    dead_radiation: int
    dead_grid: int
    grid_fraction: float
    radiation_index: float  # global normalized 0–1


# -------------------------------
# Helpers
# -------------------------------


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in km between two lat/lon points."""
    R = 6371.0
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = phi2 - phi1
    dlambda = math.radians(lon2 - lon1)
    a = (
        math.sin(dphi / 2.0) ** 2
        + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2.0) ** 2
    )
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


# -------------------------------
# Load scenario & master data
# -------------------------------


def load_strike_scenario(path: str) -> List[Dict[str, Any]]:
    if not os.path.exists(path):
        raise FileNotFoundError(f"Scenario JSON not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    strikes = data.get("strikes", [])
    if not strikes:
        raise RuntimeError("No strikes in scenario JSON.")
    print(f"[Scenario] Loaded {len(strikes):,} strikes.")
    return strikes


def load_population_model() -> Tuple[Dict[Tuple[str, str], float], int]:
    """
    Load city populations from data.csv (same logic as fast_world_strike_animation_map).

    Returns:
        (city_pop_map, world_pop_estimate)
    """
    city_pop = {}
    world_pop = DISPLAY_WORLD_POP

    try:
        import pandas as pd
    except ImportError:
        print("[Pop] pandas not available; using fallback world population.")
        return city_pop, world_pop

    if not os.path.exists(MASTER_DATA_PATH):
        print(f"[Pop] data.csv not found at {MASTER_DATA_PATH}; using fallback world population.")
        return city_pop, world_pop

    try:
        df = pd.read_csv(MASTER_DATA_PATH, low_memory=False)
    except Exception as e:
        print(f"[Pop] Failed to read data.csv: {e}; using fallback world population.")
        return city_pop, world_pop

    if "population" not in df.columns:
        print("[Pop] 'population' column missing; using fallback world population.")
        return city_pop, world_pop

    # Approximate world population from city rows only
    city_mask = False
    if "source_layer" in df.columns:
        city_mask = (df["source_layer"].astype(str).str.lower() == "cities")
    if "target_class" in df.columns:
        tc_mask = df["target_class"].astype(str).str.upper() == "CITY"
        city_mask = city_mask | tc_mask

    if city_mask is False:
        city_df = df
    else:
        city_df = df[city_mask]

    try:
        import pandas as pd  # for to_numeric
        pop_series = pd.to_numeric(city_df["population"], errors="coerce")
        pop_series = pop_series[pop_series > 0]
        total = float(pop_series.sum())
        if 1e9 < total < 2e10:
            world_pop = int(total)
        else:
            world_pop = DISPLAY_WORLD_POP
    except Exception:
        world_pop = DISPLAY_WORLD_POP

    has_city_col = "city" in city_df.columns
    has_name_col = "name" in city_df.columns

    for _, row in city_df.iterrows():
        raw_city = ""
        if has_city_col:
            raw_city = row.get("city", "")
        if (not raw_city) and has_name_col:
            raw_city = row.get("name", "")

        city = str(raw_city).strip()
        country = str(row.get("country", "")).strip()
        if not city or not country:
            continue

        try:
            pop_val = float(row.get("population", 0))
        except Exception:
            continue
        if pop_val <= 0:
            continue

        key = (country.lower(), city.lower())
        if key in city_pop:
            if pop_val > city_pop[key]:
                city_pop[key] = pop_val
        else:
            city_pop[key] = pop_val

    print(f"[Pop] Loaded {len(city_pop):,} city populations; world_pop ≈ {world_pop:,}.")
    return city_pop, world_pop


def load_infrastructure_points():
    """
    Load large cities + big power plants for the grid destruction model.

    Returns:
        city_points: List[dict(lat, lon, weight)]
        plant_points: List[dict(lat, lon, weight)]
    """
    city_points: List[Dict[str, float]] = []
    plant_points: List[Dict[str, float]] = []

    try:
        import pandas as pd
    except ImportError:
        print("[Infra] pandas not available; grid model will ignore spatial infrastructure.")
        return city_points, plant_points

    if not os.path.exists(MASTER_DATA_PATH):
        print(f"[Infra] data.csv not found at {MASTER_DATA_PATH}; skipping infra model.")
        return city_points, plant_points

    try:
        df = pd.read_csv(MASTER_DATA_PATH, low_memory=False)
    except Exception as e:
        print(f"[Infra] Failed to read data.csv: {e}; skipping infra model.")
        return city_points, plant_points

    if "lat" not in df.columns or "lon" not in df.columns:
        print("[Infra] data.csv missing lat/lon; skipping infra model.")
        return city_points, plant_points

    import pandas as pd

    df["lat"] = pd.to_numeric(df["lat"], errors="coerce")
    df["lon"] = pd.to_numeric(df["lon"], errors="coerce")
    df = df.dropna(subset=["lat", "lon"])

    if "population" in df.columns:
        df["population"] = pd.to_numeric(df["population"], errors="coerce")
    else:
        df["population"] = 0.0

    if "capacity_mw" in df.columns:
        df["capacity_mw"] = pd.to_numeric(df["capacity_mw"], errors="coerce")
    else:
        df["capacity_mw"] = 0.0

    # Big cities
    if "source_layer" in df.columns:
        city_df = df[df["source_layer"] == "cities"].copy()
    else:
        city_df = df.copy()

    big_city_df = city_df[city_df["population"] >= CITY_POP_MIN_FOR_GRID].copy()

    for _, row in big_city_df.iterrows():
        lat = float(row["lat"])
        lon = float(row["lon"])
        pop = float(row.get("population", 0.0) or 0.0)
        if math.isnan(lat) or math.isnan(lon) or pop <= 0:
            continue
        city_points.append({"lat": lat, "lon": lon, "weight": pop})

    # Big plants: nuclear + large conventional
    if "source_layer" in df.columns:
        plant_df = df[
            df["source_layer"].isin(["nuclear_power_plants", "gppd_large_plants"])
        ].copy()
    else:
        plant_df = df.copy()

    big_plant_df = plant_df[plant_df["capacity_mw"] >= PLANT_CAP_MIN_FOR_GRID].copy()

    for _, row in big_plant_df.iterrows():
        lat = float(row["lat"])
        lon = float(row["lon"])
        cap = float(row.get("capacity_mw", 0.0) or 0.0)
        if math.isnan(lat) or math.isnan(lon) or cap <= 0:
            continue
        plant_points.append({"lat": lat, "lon": lon, "weight": cap})

    print(
        f"[Infra] Loaded {len(city_points):,} big cities and {len(plant_points):,} large plants"
    )
    return city_points, plant_points


# -------------------------------
# Casualty model (same style as map)
# -------------------------------


def estimate_casualties(
    strike: Dict[str, Any],
    city_pop_map: Dict[Tuple[str, str], float],
    city_remaining_map: Dict[Tuple[str, str], float],
) -> int:
    """
    Rough casualty estimate per strike (same logic as in fast_world_strike_animation_map).

    - For city targets with known population:
        casualties = frac * remaining_city_pop
        frac ~ 0.5 * (yield / 500 kt)^0.3, capped at 1.0
    - For military targets:
        casualties ~ 20k * (yield / 100 kt)^0.3
    - For other/unknown:
        casualties ~ 50k * (yield / 100 kt)^0.3
    """
    target_type = (strike.get("target_type") or "").lower()
    to = strike.get("to", {})
    country = str(to.get("country", "")).strip().lower()
    city = str(to.get("city", "")).strip().lower()
    key = (country, city) if country and city else None
    pop_city = city_pop_map.get(key) if key else None

    if key and key in city_remaining_map:
        pop_remaining = city_remaining_map[key]
    else:
        pop_remaining = pop_city

    # Yield
    yield_kt = strike.get("expected_effective_yield_kt") or strike.get(
        "yield_mean_kt"
    ) or 100.0
    try:
        yield_kt = float(yield_kt)
    except Exception:
        yield_kt = 100.0

    if target_type == "city" and pop_remaining and pop_remaining > 0:
        frac = min(1.0, 0.5 * (yield_kt / 500.0) ** 0.3)
        casualties = int(pop_remaining * frac)
        if key:
            city_remaining_map[key] = max(0.0, pop_remaining - casualties)
        return max(0, casualties)

    elif target_type == "military":
        base = 20_000.0 * (yield_kt / 100.0) ** 0.3
        return int(base)

    else:
        base = 50_000.0 * (yield_kt / 100.0) ** 0.3
        return int(base)


# -------------------------------
# Impact events + grid shocks
# -------------------------------


def build_impact_events(
    strikes: List[Dict[str, Any]],
    city_pop_map: Dict[Tuple[str, str], float],
) -> List[ImpactEvent]:
    """
    Build ImpactEvent list from scenario strikes.
    Uses scenario's impact_time_hours (no launch-time jitter).
    """
    city_remaining_map = dict(city_pop_map)
    events: List[ImpactEvent] = []

    for s in strikes:
        to_pt = s.get("to", {})
        try:
            t_lat = float(to_pt["lat"])
            t_lon = float(to_pt["lon"])
        except (KeyError, TypeError, ValueError):
            t_lat = None
            t_lon = None

        impact_time_h = float(s.get("impact_time_hours", 0.0))

        casualties = estimate_casualties(s, city_pop_map, city_remaining_map)

        # Yield
        yield_kt = s.get("expected_effective_yield_kt") or s.get("yield_mean_kt") or 100.0
        try:
            yield_kt = float(yield_kt)
        except Exception:
            yield_kt = 100.0

        events.append(
            ImpactEvent(
                t=impact_time_h,
                casualties=int(max(0, casualties)),
                yield_kt=yield_kt,
                lat=t_lat,
                lon=t_lon,
            )
        )

    events.sort(key=lambda e: e.t)
    if events:
        print(
            f"[Events] Built {len(events):,} impact events; "
            f"first at t={events[0].t:.2f} h, last at t={events[-1].t:.2f} h"
        )
    else:
        print("[Events] No impact events constructed?")

    return events


def assign_grid_shock_to_events(
    events: List[ImpactEvent],
    city_points: List[Dict[str, float]],
    plant_points: List[Dict[str, float]],
) -> float:
    """
    For each impact event assign a dimensionless grid_shock based on
    yield and proximity to large cities / power plants.
    Returns total_shock for normalization.
    """
    if not events:
        return 0.0

    total_shock = 0.0

    for evt in events:
        if evt.lat is None or evt.lon is None:
            evt.grid_shock = 0.0
            continue

        base = max(0.0, (evt.yield_kt / 100.0) ** 0.5)

        # Proximity to mega-cities
        city_factor = 0.0
        for cp in city_points:
            dist = haversine_km(evt.lat, evt.lon, cp["lat"], cp["lon"])
            if dist > CITY_MAX_DIST_KM:
                continue
            # population scaled to tens of millions
            pop_scale = cp["weight"] / 10_000_000.0
            city_factor += pop_scale * math.exp(-dist / CITY_DIST_DECAY_KM)

        # Proximity to large plants
        plant_factor = 0.0
        for pp in plant_points:
            dist = haversine_km(evt.lat, evt.lon, pp["lat"], pp["lon"])
            if dist > PLANT_MAX_DIST_KM:
                continue
            cap_scale = pp["weight"] / 1000.0  # GW scale
            plant_factor += cap_scale * math.exp(-dist / PLANT_DIST_DECAY_KM)

        # Weighted combo (plants matter more for grid)
        infra_factor = 0.4 * city_factor + 0.6 * plant_factor
        shock = base * infra_factor

        evt.grid_shock = shock
        total_shock += shock

    print(f"[Grid] Total unscaled grid shock from all events: {total_shock:.3f}")
    return total_shock


# -------------------------------
# Radiation series (global scalar)
# -------------------------------


def _compute_component_lambdas() -> List[Tuple[float, float]]:
    """
    Convert RADIATION_COMPONENTS to list of (weight, lambda_per_hour).
    """
    comps = []
    total_w = sum(c["weight"] for c in RADIATION_COMPONENTS)
    if total_w <= 0:
        total_w = 1.0

    for comp in RADIATION_COMPONENTS:
        w = comp["weight"] / total_w
        hl = comp["half_life_hours"]
        hl = max(hl, 0.1)
        lam = 0.693 / hl
        comps.append((w, lam))
    return comps


def build_radiation_series(
    events: List[ImpactEvent],
    t_end: float,
    dt_hours: float = RADIATION_SERIES_DT_HOURS,
) -> List[Dict[str, float]]:
    """
    Build a global radiation index time series from t=0 to t_end,
    using multi-component exponential decay.

    Returns list of dicts:
        {"t": hours, "index_raw": value, "index": normalized_0_1}
    """
    if not events:
        return [{"t": 0.0, "index_raw": 0.0, "index": 0.0}]

    comps = _compute_component_lambdas()
    events_sorted = sorted(events, key=lambda e: e.t)
    times: List[Dict[str, float]] = []

    t = 0.0
    while t <= t_end + 1e-6:
        total_raw = 0.0
        for evt in events_sorted:
            if t < evt.t:
                break
            dt = t - evt.t
            for w, lam in comps:
                total_raw += evt.yield_kt * w * math.exp(-lam * dt)
        times.append({"t": t, "index_raw": total_raw})
        t += dt_hours

    max_raw = max((r["index_raw"] for r in times), default=1.0)
    if max_raw <= 0:
        max_raw = 1.0
    for r in times:
        r["index"] = r["index_raw"] / max_raw

    print(
        f"[Radiation] Built radiation series from t=0 to t={t_end:.1f} h "
        f"({len(times)} points, dt={dt_hours} h)"
    )
    return times


def get_radiation_index_at(
    hours: float, radiation_series: List[Dict[str, float]]
) -> float:
    """Piecewise-constant lookup of normalized radiation index."""
    if not radiation_series:
        return 0.0
    series = radiation_series
    if hours <= series[0]["t"]:
        return series[0]["index"]
    for i in range(1, len(series)):
        if hours < series[i]["t"]:
            return series[i - 1]["index"]
    return series[-1]["index"]


# -------------------------------
# Radiation spatial frames for heatmap
# -------------------------------


def build_radiation_heat_frames(
    events: List[ImpactEvent],
    radiation_series: List[Dict[str, float]],
    t_end: float,
    dt_hours: float = RADIATION_HEATMAP_DT_HOURS,
) -> List[Dict[str, Any]]:
    """
    Build per-hour radiation frames for a dynamic heatmap.

    Each frame:
        {"t": hours, "points": [[lat, lon, weight_0_1], ...]}

    We reuse the same decay kernel as the global scalar index; weight is
    normalized against the global max radiation.
    """
    if not events:
        return []

    comps = _compute_component_lambdas()
    events_sorted = [e for e in events if e.lat is not None and e.lon is not None]

    if not events_sorted:
        return []

    # Use global max_raw from radiation_series for normalization
    max_raw = max((r["index_raw"] for r in radiation_series), default=1.0)
    if max_raw <= 0:
        max_raw = 1.0

    frames: List[Dict[str, Any]] = []
    t = 0.0
    while t <= t_end + 1e-6:
        pts: List[List[float]] = []
        for evt in events_sorted:
            if t < evt.t:
                continue
            dt = t - evt.t
            if dt > RADIATION_SPATIAL_TAU_CUTOFF_HOURS:
                continue
            local_raw = 0.0
            for w, lam in comps:
                local_raw += evt.yield_kt * w * math.exp(-lam * dt)
            w_norm = local_raw / max_raw
            if w_norm <= 0:
                continue
            pts.append([evt.lat, evt.lon, float(max(0.0, min(1.0, w_norm)))])
        frames.append({"t": t, "points": pts})
        t += dt_hours

    print(
        f"[Radiation] Built {len(frames)} radiation heatmap frames "
        f"(dt={dt_hours} h, cutoff={RADIATION_SPATIAL_TAU_CUTOFF_HOURS} h)"
    )
    return frames


# -------------------------------
# Population + grid simulation (minute step)
# -------------------------------


def simulate_population_and_grid(
    events: List[ImpactEvent],
    radiation_series: List[Dict[str, float]],
    total_shock: float,
    t_end: float,
    dt_hours: float = SIM_DT_HOURS,
) -> List[TimeState]:
    """
    Minute-resolution simulation of:
      - remaining population
      - cumulative deaths by cause
      - grid fraction (0–1)
      - radiation index (0–1)

    Uses:
      * immediate blast/thermal deaths at impact times
      * ongoing radiation deaths
      * ongoing grid-collapse deaths
      * grid physical damage from grid_shock
      * slow dynamic grid collapse under stress

    Returns list of TimeState entries (one per time step).
    """
    if not events:
        # trivial flat series
        return [
            TimeState(
                t=0.0,
                remaining=DISPLAY_WORLD_POP,
                dead_blast=0,
                dead_radiation=0,
                dead_grid=0,
                grid_fraction=1.0,
                radiation_index=0.0,
            )
        ]

    # sort events
    events_sorted = sorted(events, key=lambda e: e.t)
    last_impact_t = events_sorted[-1].t

    survivors = float(DISPLAY_WORLD_POP)
    dead_blast = 0.0
    dead_rad = 0.0
    dead_grid = 0.0

    grid_fraction = 1.0

    states: List[TimeState] = []

    # pointer into events
    idx = 0
    n_events = len(events_sorted)

    t = 0.0
    while t <= t_end + 1e-9 and survivors > 0:
        next_t = t + dt_hours

        # Apply any impacts whose time falls in [t, next_t)
        while idx < n_events and events_sorted[idx].t < t - 1e-9:
            idx += 1  # safety advance

        while idx < n_events and events_sorted[idx].t < next_t + 1e-9:
            evt = events_sorted[idx]
            direct = min(float(evt.casualties), survivors)
            if direct > 0:
                survivors -= direct
                dead_blast += direct

                # immediate physical grid damage
                if total_shock > 0 and evt.grid_shock > 0:
                    frac = evt.grid_shock / total_shock
                    drop = GRID_PHYSICAL_MAX_DROP * frac
                    grid_fraction = max(GRID_MIN_FRACTION, grid_fraction - drop)

            idx += 1

        # Radiation index at current time (hourly series interpolated piecewise constant)
        rad_idx = get_radiation_index_at(t, radiation_series)
        rad_idx = max(0.0, min(1.0, rad_idx))

        # Overall dead fraction
        dead_frac_total = 1.0 - (survivors / DISPLAY_WORLD_POP)

        # Dynamic grid degradation under stress
        stress = 0.3 + 0.7 * ((rad_idx + dead_frac_total) / 2.0)
        grid_fraction = max(
            GRID_MIN_FRACTION,
            grid_fraction - GRID_DYNAMIC_DECAY_RATE * dt_hours * stress,
        )
        grid_fraction = min(1.0, grid_fraction)

        # Post-war radiation mortality (continuous)
        # Convert daily max into this time step
        rad_daily = RAD_POSTWAR_DAILY_MORTALITY_MAX * (rad_idx ** RAD_MORTALITY_EXP)
        rad_frac_step = rad_daily * (dt_hours / 24.0)
        rad_frac_step = max(0.0, min(0.2, rad_frac_step))  # cap to avoid blowups

        rad_deaths = survivors * rad_frac_step
        survivors -= rad_deaths
        dead_rad += rad_deaths

        # Grid-collapse mortality
        blackout = 1.0 - grid_fraction
        grid_daily = GRID_POSTWAR_DAILY_MORTALITY_MAX * (blackout ** GRID_MORTALITY_EXP)
        grid_frac_step = grid_daily * (dt_hours / 24.0)
        grid_frac_step = max(0.0, min(0.2, grid_frac_step))

        grid_deaths = survivors * grid_frac_step
        survivors -= grid_deaths
        dead_grid += grid_deaths

        if survivors < 0:
            survivors = 0.0

        states.append(
            TimeState(
                t=t,
                remaining=int(round(survivors)),
                dead_blast=int(round(dead_blast)),
                dead_radiation=int(round(dead_rad)),
                dead_grid=int(round(dead_grid)),
                grid_fraction=float(grid_fraction),
                radiation_index=float(rad_idx),
            )
        )

        t = next_t

    print(
        f"[Sim] Generated {len(states):,} time steps (dt={dt_hours*60:.0f} min) "
        f"to t={t_end:.1f} h"
    )
    if states:
        last = states[-1]
        total_dead = (
            last.dead_blast + last.dead_radiation + last.dead_grid
        )
        print(
            f"[Sim] Final survivors: {last.remaining:,}; "
            f"deaths: {total_dead:,} "
            f"(blast={last.dead_blast:,}, rad={last.dead_radiation:,}, grid={last.dead_grid:,})"
        )
    return states


# -------------------------------
# Main driver
# -------------------------------


def main():
    print(f"[Paths] Scenario: {SCENARIO_PATH}")
    print(f"[Paths] Master data: {MASTER_DATA_PATH}")
    print(f"[Paths] Output env: {OUTPUT_ENV_PATH}")

    strikes = load_strike_scenario(SCENARIO_PATH)

    # Population model for casualties
    city_pop_map, world_pop_est = load_population_model()
    print(f"[Pop] world_pop_est ≈ {world_pop_est:,}; display uses {DISPLAY_WORLD_POP:,}.")

    # Impact events
    impact_events = build_impact_events(strikes, city_pop_map)
    if not impact_events:
        raise RuntimeError("No impact events; cannot build environment model.")

    last_impact_t = impact_events[-1].t
    t_end = last_impact_t + POSTWAR_DAYS * 24.0

    # Infrastructure points (for grid shocks)
    city_points, plant_points = load_infrastructure_points()
    total_shock = assign_grid_shock_to_events(
        impact_events, city_points, plant_points
    )

    # Radiation global index (hourly)
    radiation_series = build_radiation_series(impact_events, t_end)

    # Radiation spatial frames for dynamic heatmap (hourly)
    radiation_heat_frames = build_radiation_heat_frames(
        impact_events, radiation_series, t_end
    )

    # Full population & grid simulation at minute resolution
    states = simulate_population_and_grid(
        impact_events,
        radiation_series,
        total_shock,
        t_end,
        dt_hours=SIM_DT_HOURS,
    )

    # Build output JSON
    env = {
        "meta": {
            "source_scenario_file": os.path.basename(SCENARIO_PATH),
            "generated_at": None,
            "display_world_population": DISPLAY_WORLD_POP,
            "world_population_estimate": world_pop_est,
            "postwar_days": POSTWAR_DAYS,
            "sim_dt_hours": SIM_DT_HOURS,
            "radiation_series_dt_hours": RADIATION_SERIES_DT_HOURS,
            "radiation_heatmap_dt_hours": RADIATION_HEATMAP_DT_HOURS,
            "radiation_components": RADIATION_COMPONENTS,
            "grid_min_fraction": GRID_MIN_FRACTION,
            "grid_physical_max_drop": GRID_PHYSICAL_MAX_DROP,
            "grid_dynamic_decay_rate": GRID_DYNAMIC_DECAY_RATE,
            "rad_postwar_daily_mortality_max": RAD_POSTWAR_DAILY_MORTALITY_MAX,
            "grid_postwar_daily_mortality_max": GRID_POSTWAR_DAILY_MORTALITY_MAX,
            "rad_mortality_exp": RAD_MORTALITY_EXP,
            "grid_mortality_exp": GRID_MORTALITY_EXP,
        },
        "time_series": [asdict(s) for s in states],
        "radiation_series": radiation_series,
        "radiation_heat_frames": radiation_heat_frames,
    }

    os.makedirs(PROCESSED_DIR, exist_ok=True)
    with open(OUTPUT_ENV_PATH, "w", encoding="utf-8") as f:
        json.dump(env, f, indent=2)

    print(f"[Output] Wrote environment timeline to {OUTPUT_ENV_PATH}")


if __name__ == "__main__":
    main()
